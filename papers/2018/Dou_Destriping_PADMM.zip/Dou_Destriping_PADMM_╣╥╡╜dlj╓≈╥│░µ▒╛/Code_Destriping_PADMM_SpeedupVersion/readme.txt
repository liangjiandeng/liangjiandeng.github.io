==================================================
This is matlab demo for the submitted manuscript:

Directional l0 Sparse Modeling for Image Stripe Noise Removal

by Hong-Xia Dou, et al.
==================================================
Code written by: Hong-Xia Dou (UESTC)
=================================================

Please cite the following references if you use this code:

[1] HX Dou, TZ Huang, LJ Deng, XL Zhao, J Huang, Directional l0 Sparse Modeling for Image Stripe Noise Removal, Remote Sensing, 10 (3), 361, 2018

[2] Y Chen, TZ Huang, LJ Deng, XL Zhao, M Wang, Group sparsity based regularization model for remote sensing image stripe noise removal, Neurocomputing 267, 95-106, 2017

[3] Y Chen, TZ Huang, XL Zhao, LJ Deng, J Huang, Stripe noise removal of remote sensing images by total variation regularization and group sparsity constraint, Remote Sensing 9 (6), 559, 2017




==================================================
============= Run Description ====================
==================================================

Please run:

Demo_synth.m  for synthetic images

Demo_real.m  for real images

==================================================
============= Note that ====================
==================================================

If you want to compare our method, please use the same 
stopping criterion for fair computation comparisons. 

See the following example of a common stopping criterion:
(you can also use the stoping criterion mentioned in our paper)
%====initial setting=======
U       = B;
iter    = 1;
all     = 10;
MaxIter = 1e03;

while all > acc && iter < MaxIter

.........................
        
    all = norm(U-Ucomp, 'fro')/norm(U, 'fro');
    
    iter = iter + 1;
end

==================================================

We also show the result by Yi Chang, et al.
Reader can find the code from: 

http://www.escience.cn/people/changyi/codes.html

Also, you may find the codes of UTV, SGE, WFAF from this link. 



