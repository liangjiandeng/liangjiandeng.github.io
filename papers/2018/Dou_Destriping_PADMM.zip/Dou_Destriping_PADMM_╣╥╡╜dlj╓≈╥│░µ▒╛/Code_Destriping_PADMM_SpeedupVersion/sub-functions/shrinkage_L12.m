function [x] = shrinkkage_L12(A,lambda,beta,p)
% This program solves the following OP:
% min_{x} lambda*||x||1 + beta/2*||x - a||_2^2
% Here we assume b>=0
if(p==1)
     x = sign(A).*max(0,abs(A)-(lambda/beta));
elseif(p==2)
     normx = sqrt(A.^2 );
     Weight = max(0,1 - (lambda/beta)./ normx);
     x = A.*Weight; 
end