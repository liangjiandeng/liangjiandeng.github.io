function [B]   =  SVD_shrink(I, X, svdMethod, opts )

rank_B = opts.rank_B;

for iter = 1:opts.Innerloop_B
%% B-subproblem

    switch lower(svdMethod)
        case 'svdlibc'
            [U, diagS, V] = svdlibc(I- X, rank_B+1);
        case 'propack'
            [U,S,V] = lansvd(I- X,rank_FPN+1,'L');
            diagS = diag(S);
        case 'svds'
            [U, S, V] = svds(I- X, rank_B+1, 'L');
            diagS = diag(S);
        otherwise            
            [U,S,V] = svd(I- X,0);            
            diagS = diag(S);            
    end
    temp    = (diagS-opts.tau/opts.delta).*double( (diagS-opts.tau/opts.delta) > 0 );
    B       = U * diag(temp) * V';
%     opts.tau = opts.tau/opts.delta;
%     temp    = (diagS-opts.tau).*double( (diagS-opts.tau) > 0 );
%     B       = U * diag(temp) * V';
%     rank_B   = sum(diagS>opts.tau);
%     opts.tau = opts.tau*opts.delta;
end
