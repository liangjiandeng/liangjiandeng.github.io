function [R] = difY1(X)
R = X(:,[2:end end],:)-X;