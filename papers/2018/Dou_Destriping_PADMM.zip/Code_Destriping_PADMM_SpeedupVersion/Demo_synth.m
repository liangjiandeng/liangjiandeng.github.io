%% demo of 1 synthetic image with all methods 
%% H.-X Dou (UESTC)
%% ===========================

clc;clear all;close all;
addpath(genpath('test-mat\'));
addpath('main-solvers','sub-functions','scratched');
randn('seed',0);rand('seed',0)

%% read images
[filename, filepath, FilterIndex ] = uigetfile('synth_imgs/*.*','Read image');
I =  double(imread(fullfile(filepath,filename))) ;
% % --------- Degraded simulation -------------------
Perio = 10;
rate = 0.2;
mean = 50;
% Is  =  Periodical_Simulated(I,Perio,rate,mean);
Is   =  NonPeriodical_Simulated(I,rate,mean);

% % -------- normalization trans into our press -------------------
adds = Is - I;
adds = adds/255;
B_Clean = I/255;
B_Corrupted = Is/255;

%% show  the  class  for  testing now
disp('===mean====rate=======name============') 
disp(['|| ',  num2str(mean),   ' || ',...
    ' ',   num2str(rate),   ' || ',...
    ' ',   num2str(filename),   ' ||']) 
disp('**********************************************') 

% ============= LRSID ============= 
% The code of LRSID is available from: http://www.escience.cn/people/changyi/codes.html
% Readers can find the codes of UTV, SGE, WFAF from this link.
% If you use this code, please cite their corresponding references.
% for single image initialize
opt5.belta = 1e-04;
opt5.lamda2 = 1e-05; % total variational row constraint    tao-x
opt5.gamma = 0.01 ; 
opt5.lamda3 = 0.003; % total variational colomn constraint  0.003   tao-y
opt5.delta = 0.01;   
opt5.tau = 0.1;   % low-rank constraint
opt5.MaxIter = 1000;
opt5.Innerloop_B = 1;
opt5.rank_B = 1;      

tic
[u_LRSID, s_LRSID] = SILR_destripe(B_Corrupted,opt5);
toc

psnr_LRSID = psnr(B_Clean,u_LRSID);
ssim_LRSID = ssim(255*B_Clean,255*u_LRSID);

disp('====== LRSID ==========')
disp('====PSNR=====SSIM=======') 
disp(['    ' , '|| ',  num2str(psnr_LRSID), '    ' , ' || ', '    ' ,  num2str(ssim_LRSID)]) 
disp('**********************************************') 


%% ============= Proposed ============= 
opt6.lambda = 1; 
opt6.mu = 0.1;
opt6.beta1 = 1e02;
opt6.beta2 = 1e01;
opt6.beta3 = 1e01;
opt6.beta4 = 1e03;
%acc = 1/10;  % for stopping 1
acc = 5e-5;  % for stopping 2

tic
[s_our, iter] = our_synt(B_Corrupted,opt6,acc);
toc

u_our = B_Corrupted - s_our;

psnr_ours = psnr(B_Clean,u_our);
ssim_ours = ssim(255*B_Clean,255*u_our);

disp('====== Our ==========')
disp('====PSNR=====SSIM=======') 
disp(['    ' , '|| ',  num2str(psnr_ours), '    ' , ' || ', '    ' ,  num2str(ssim_ours)]) 
disp('**********************************************') 

%% %% %%  show the  all images %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure, 
subplot(2,2,1), imshow(B_Clean,[]); title('Clean-image','fontsize',13);
subplot(2,2,2), imshow(B_Corrupted,[]); title('Corrupted-image','fontsize',13);
subplot(2,2,3), imshow(u_LRSID,[]); title('LRSID','fontsize',13);
subplot(2,2,4), imshow(u_our,[]); title('Proposed','fontsize',13);

figure,
subplot(1,3,1); imshow(adds,[]); title('S-added','fontsize',13);
subplot(1,3,2); imshow(s_LRSID,[]); title('S-LRSID','fontsize',13);
subplot(1,3,3); imshow(s_our,[]); title('S-Our','fontsize',13);





