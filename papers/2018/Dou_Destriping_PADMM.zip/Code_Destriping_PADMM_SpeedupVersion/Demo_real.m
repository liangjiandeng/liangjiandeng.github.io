%% demo of 1 real image with all methods 
%% H.-X Dou (UESTC)
%% ===========================
clc;clear all;close all;
addpath(genpath('test-mat\'));
addpath('main-solvers','sub-functions','scratched');
randn('seed',0);rand('seed',0)

%% read images
[filename, filepath, FilterIndex ] = uigetfile('real_imgs/*.*','Read image');
Is =  double(imread(fullfile(filepath,filename)))/255 ;

% ============== LRSID ============= 
% The code of LRSID is available from: http://www.escience.cn/people/changyi/codes.html
% Readers can find the codes of UTV, SGE, WFAF from this link.
% for single image initialize
opt5.belta = 1e-04;
opt5.lamda2 = 1e-05; % total variational row constraint    tao-x
opt5.gamma = 0.01 ; 
opt5.lamda3 = 0.003; % total variational colomn constraint  0.003   tao-y
opt5.delta = 0.01;   
opt5.tau = 0.1;   % low-rank constraint
opt5.MaxIter = 1000;
opt5.Innerloop_B = 1;
opt5.rank_B = 1;  

tic
[u_LRSID, s_LRSID] = SILR_destripe(Is,opt5);
toc

%% ============= Proposed ==============
opt6.lambda = 10;  
opt6.mu = 0.1;
opt6.beta1 = 1e0;
opt6.beta2 = 1e0;
opt6.beta3 = 1e0;
opt6.beta4 = 1e0;
%acc = 1/10;  % for stopping 1
acc = 5e-5;  % for stopping 2

tic
[s_our, iter] = our_real(Is,opt6,acc);  
toc

u_our = Is - s_our;

%% %% %%  show the  all images %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure, 
subplot(1,3,1), imshow(Is,[]); title('Striped Img','fontsize',13);
subplot(1,3,2), imshow(u_LRSID,[]); title('LRSID','fontsize',13);
subplot(1,3,3), imshow(u_our ,[]); title('Proposed','fontsize',13);





