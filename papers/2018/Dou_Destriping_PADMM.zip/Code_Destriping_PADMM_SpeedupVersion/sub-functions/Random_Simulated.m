function NonP_Stripe   =  NonPeriodical_Simulated(Ori,rate,mean)


rand('seed',0);
[Row, Col] = size(Ori);
Location = randperm(Col,round(rate*Col));
u=randi([0 50],1,length(Location));
S=zeros(Row,Col);
S(:,Location(1:round(rate*Col/2)))=S(:,Location(1:round(rate*Col/2)))...
    + repmat(u(1:round(rate*Col/2)),Row,1);
S(:,Location(round(rate*Col/2)+1:round(rate*Col)))=...
           S(:,Location(round(rate*Col/2)+1:round(rate*Col))) - repmat(u(round(rate*Col/2)+1:length(Location)),Row,1);
 NonP_Stripe=Ori+S;      
 
 
 