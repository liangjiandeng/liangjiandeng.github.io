function [s,iter, pi1,pi2,pi3,pi4] = our_synt(B,opt,acc)
%% ����Ҫ����ԭʼͼ��ĺ���B_Clean �Լ� ������λ��������ϢO

% This program solves the following optimization problem:
% min_{s}  lambda || Dy(b-s) ||_{p,1} + || Dx(s)||_0
% where b = u + s, ������ʱû�п���ģ��K����

% Input parameters:
% B: m x n, the corrupted image
% Kmap,Ktmap: the linear operator and its adjoint operator
% p: p = 1 (anisotropic) or p = 2 (isotropic)
% lambda: the regularization parameter
% LargestEig: the square of largest singular value of the linear operator
% acc: accuracy of the optimization problem, acc = 1/255
% B_Clean: the original clean image

% Output parameter:
% U: recovered image
 
% We solve the OP by PADMM:
% min_{u,v} lambda sum_c=1^3 || Dxu Dyu ||_{p,1} + sum_c=1^3 <e,e-v>,   s.t. <o.*|Au-b|,v> = 0
% min_{u,v,r,s,z} sum_c=1^3 lambda || r s ||_{p,1} + sum_c=1^3 <e,e-v>, s.t. <o.*|z|,v> = 0, Au-b = z, Dxu = r, Dyu = s
% L(u,v,r,s,z) =  sum_c=1^3 lambda || r s ||_{p,1}  + sum_c=1^3 <e,e-v>
%                                  + <piz, Au-b-z> + 0.5 alpha |Au-b-z|_2^2
%                                  + <pir, Dxu-r> + 0.5 beta |Dxu-r|_2^2
%                                  + <pis, Dyu-s> + 0.5 beta |Dyu-s|_2^2,
%                                  + <piv, o.*|z|.*v> + 0.5 rho |o.*|z|.*v|_2^2

%% ��ʼ��
rand('seed',0)
sizeB = size(B);
b = B;
s = zeros(sizeB);
V = ones(sizeB);  % V��MPEC�����е��滻����������ȫ1�ĳ�ʼֵ

Dt = defDT;
Dx = defDX; % �в��
Dy = defDY; % �в��
dybs = Dy(b-s);
dxs = Dx(s);

% Multipliers  ������ĳ�ʼֵ
pi1 = 1e-4*randn(sizeB);
pi2 = 1e-4*randn(sizeB);
pi3 = 1e-4*randn(sizeB);
pi4 = 1e-4*randn(sizeB);  

% gamma = 1;
gamma = 0.5*(1+sqrt(5)); %  golden ratio
% �������� % beta1=1e05,beta2=1e06,beta3=1e06,beta4=1e05
          % 1e06, 1e06, 1e06, 1e06
lambda = opt.lambda;
mu = opt.mu;
beta1 = opt.beta1; 
beta2 = opt.beta2; 
beta3 = opt.beta3; 
beta4 = opt.beta4; 

%----initial setting----
U       = B;
iter    = 1;
all     = 10;
MaxIter = 1e03;

while all > acc && iter < MaxIter
     % Update H
     Hop1 =  beta1*dxs + pi1;
     Hop2 = V.*pi4;
     Hop3 = beta1  + beta4*V.*V;
     H = threadholding_l1_w(Hop1./Hop3,Hop2./Hop3);
     
     % Update Z
     Zop = s + pi2/beta2;
     lz = 1;
     Z = shrinkage_L12(Zop,mu,beta2,lz);
     
     
    % Update W
    Wop = dybs + pi3/beta3;
    lp = 1;
    W = shrinkage_L12(Wop,lambda,beta3,lp); % p����������shringkage-1,2�������
    
    % Update V
%     Vop1 = 1 + pi4.*abs(H);
    Vop1 = 1 - pi4.*abs(H);
    Vop2 = beta4*abs(H).*abs(H);
    V = boxproj(Vop1./Vop2);
    
    % Update s
    Ucomp = U;
    tem1 = pi1 + beta1*(dxs - H);
    tem2 = -pi3 - beta3*(dybs - W);
    Tem = Dt(tem2,tem1);
    Sop = Tem + pi2 + beta2*(s -Z);
    Lip = beta1*4 + beta2*1 + beta3*4;
    s = s - Sop/Lip;
%     s = boxproj(s - Sop/Lip);  % boxproj���ǽ���������г���0-1֮���������Ϊ0��1
    
    U = B - s;

    % Update the dxs,dybs
    dxs = Dx(s);
    dybs = Dy(b-s);
    
    % Update mults
    pi1 = pi1 + gamma*beta1*(dxs - H);
    pi2 = pi2 + gamma*beta2*(s - Z);
    pi3 = pi3 + gamma*beta3*(dybs - W);
    pi4 = pi4 + gamma*beta4*(V.*abs(H));
     
    % Update the data
    dxsh = dxs - H;
    sz = s - Z;
    dybsw = dybs - W;
    vds = V.*abs(H);
    
    % stopping criterion 1
%     r1 = fnorm(dxsh); 
%     r2 = fnorm(sz);
%     r3 = fnorm(dybsw);
%     r4 = fnorm(vds);
%     all = r1 + r2 + r3 +r4;
    
    % stopping criterion 2
    
    all = norm(U-Ucomp, 'fro')/norm(U, 'fro');
    
    iter = iter + 1;

end
%%  
function Dx = defDX  % �в��
 Dx = @(U) ForwardDx(U);
end
function Dy = defDY
 Dy = @(U) ForwardDy(U); % �в��
end

function [Duy] = ForwardDy(U)
Duy = [diff(U,1,2), U(:,1) - U(:,end)];
end

function [Dux] = ForwardDx(U)
Dux = [diff(U,1,1); U(1,:) - U(end,:)];
end

function Dt=defDT
Dt= @(X,Y) Dive(X,Y);
end

function DtXY = Dive(X,Y)
DtXY = [X(:,end) - X(:, 1), -diff(X,1,2)];
DtXY = DtXY + [Y(end,:) - Y(1, :); -diff(Y,1,1)];
end

end








