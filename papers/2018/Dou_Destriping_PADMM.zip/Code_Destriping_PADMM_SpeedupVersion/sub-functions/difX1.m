function [R] = difX1(X)
R = X([2:end end],:,:)-X;
