function [u] = WFAFfunc(B_Corrupted,opt1)

img = opt1.img;
numlev = opt1.numlev;
wavtyp = opt1.wavtyp;
k = opt1.k;
% wavelet decomposition

for i=1:numlev
   [img,hd{i},vd{i},dd{i}] =dwt2(img,wavtyp);
end

%%% FFT transform
vd = adpative_FFT( vd, numlev,k);
  
% Reconstruction
newimg = img;
for i=numlev:-1:1
   newimg=newimg(1:size(hd{i},1),1:size(hd{i},2));
   newimg=idwt2(newimg,hd{i},vd{i},dd{i},wavtyp);
end

u = newimg;
end