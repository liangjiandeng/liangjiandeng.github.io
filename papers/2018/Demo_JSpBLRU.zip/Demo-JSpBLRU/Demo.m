% Example #1. toy example
%% generate data
 clear;close all;clc
L = 224; % L : number of specral bands
N = 50;  % N : number of endmembers
K = 9;   % K : number of pixels
numpat  = [3 3 3];         % partition, d=d_1=d_2=d_3=3
K0      = length(numpat);  % number of blocks
MaxIter = 2000;
SNR     = 30;

load USGS_pruned_10_deg.mat

% construct dictionary
F  = B(:,randperm(size(B,2),N));

% construct abundance matrix
t = linspace(0.8,0.9,K0); % sparsity
W = [];
for i = 1:K0
    Wt = constAbundance(t(i), N, numpat(i));
    W = [W Wt];
end

% construct noisy reflective matrix
Y0      = F*W;
sigma   = sqrt(sum(sum((Y0).^2))/numel(Y0)/10^(SNR/10));
e       = sigma*randn(L,size(W,2));
Y       = F*W+ e ;
SNR_est = 10*log10(sum(sum((Y0).^2))/sum(sum(e.^2)));

%% Searching optimal parameters for JSpBLRU
parameter.verbose = 0;
parameter.K0      = K0;
parameter.MaxIter = MaxIter;
parameter.numpat  = numpat;
parameter.mu      = 0.01; % it is suggested to choose optimal mu from 10.^[-3:0]

gamma = [0 10^-6 0.00001 0.0001 5*10^-4 0.001 0.005 0.01 0.05 0.1 0.5 1 5];
tau   = [0 10^-6 0.00001 0.0001 5*10^-4 0.001 0.005 0.01 0.05 0.1 0.5 1 5];
no_l1 = size(gamma,2);
no_l2 = size(tau,2);

RMSE_temp = zeros(no_l1,no_l2);

kk0 = waitbar(0, 'Searching optimal parameters for JSpBLRU ...');
kk = 1;
for j1=1:no_l1
    for j2 = 1:no_l2
        waitbar(kk/(no_l1*no_l2), kk0)
        kk = kk+1;
        parameter.gamma  = gamma(j1);
        parameter.tau    = tau(j2);
        W_comp           = JSpBLRU(Y,F,parameter);
        RMSE_temp(j1,j2) = sqrt(mean((W_comp(:) - W(:)).^2));
    end
end
close(kk0)

[~,ind ]          = min(RMSE_temp(:));
[par_sp,par_rank] = ind2sub(size(RMSE_temp),ind);
parameter.gamma   = gamma(par_sp);
parameter.tau     = tau(par_rank);

%% JSpBLRU with optimal gamma and tau
parameter
tic;
W_JSpBLRU   = JSpBLRU(Y,F,parameter);
CPU = toc;
CPU = round(10000*CPU)/10000;

RMSE = sqrt(mean( (W(:) - W_JSpBLRU(:)).^2 ) );
RMSE = round(10000*RMSE)/10000;

SRE = 10*log10( sum(W_JSpBLRU(:).^2) / sum( (W(:) - W_JSpBLRU(:)).^2 ) );
SRE = round(100*SRE)/100;
disp([' RMSE: ' num2str(RMSE), ', SRE: ', num2str(SRE), ', Time: ', num2str(CPU)])

%% display images
figure(1),
subplot(131),imagesc(W),title('Original X')
subplot(132),imagesc(W_JSpBLRU),title('JSpBLRU')
subplot(133),imagesc(abs(W_JSpBLRU-W),[0,1]),title('Error_ JSpBLRU')

