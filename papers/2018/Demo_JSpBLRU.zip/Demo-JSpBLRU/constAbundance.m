function W = constAbundance(spar_deg, N, numpat)
I1 = randperm(N,round(spar_deg * N));
W        = rand(N,1)*rand(1,numpat);
W(I1,:)  = 0;