function [s,ii]=ugsm(I,opts)
%% ---the right version!!!!
%Note:
%  There are some inconsistences with the paper, i.e., p1, p3, lambda1, 
%  lambda2, beta1, beta2, which have been stated in the code. 
%  Sorry for the confusion!!!

[m,n]=size(I);
C=getC(I);
D1=defDD1t;  %x-direction finite function
D2=defDD2t;  %y-direction finite function
Dt=defDDt;

%%%%--------------initialization----------%%%%
f=I;            
s=zeros(m,n);   % There are some inconsistences with the paper. 
p1=zeros(n,m);      % here's p1 means p3 in the paper. 
p2=p1;          
p3=p1;              % here's p3 means p1 in the paper. 
lamda1=opts.lamda1; % here's lambda1 means lmabda2 in the paper. 
lamda2=opts.lamda2; % here's lambda2 means lmabda1 in the paper. 
beta1=opts.beta1;   % here's beta1 means beta3 in the paper. 
beta2=opts.beta2;   
beta3=opts.beta3;   % here's beta3 means beta1 in the paper.
tol=opts.tol;
maxitr=opts.maxitr;
%Denom=beta1*C.eigsD1tD1+beta2*eyes(m,n)+beta3*C.eigsD2tD2;  
Denom=beta3*C.eigsD1tD1+beta2*ones(m,n)+beta1*C.eigsD2tD2;%% eyes(m,n)

%%%%--------------finite diff-------------%%%%
D2s=D2(s);         %   d_y(s)
D1s=D1(f-s);       %   d_x(f-s) means d_x(r-s) in the paper
%%%%--------------Main loop---------------%%%%
ii=0;
relchg=1;
y=zeros(m,n);
while relchg> tol && ii<maxitr 
    V1=D2s+p1'/beta1;
    V2=D1s+p3'/beta3;
    %%%%----------w-subproblem: Eq.(23), here denoted as x-subpro------------%%%%
    x=sign(V1).*max(0,abs(V1)-1/beta1);
    %%%%----------u-subproblem: Eq.(19), here denoted as z-subpro------------%%%%
    z=sign(V2).*max(0,abs(V2)-lamda2/beta3);
    %%%%----------v-subproblem: Eq.(21), here denoted as y-subpro------------%%%%
    V3=s+p2'/beta2;
    y = sign(V3).*max(0,abs(V3)-lamda1/beta2);
    %%%%----------s-subproblem------------%%%%
    sp=s;
    temp1=beta3*D1(f)-beta3*z+p3'; % the 2nd term of the right side of Eq.(25); not include Dx'
    temp2=beta2*y-p2'; % the 2rd term of the right side of Eq.(25); not include Dy'
    temp3=beta1*x-p1'; % the 1st term of the right side of Eq.(25)
    s1=Dt(temp1,temp3)+temp2; % the right side of Eq.(25)
    s2=fft2(s1)./Denom;
    s=real(ifft2(s2)); % s_hat
    s(s<0) = 0;        % Eq.(26)
    index = find(s>f); 
    s(index) = f(index);

    u1=f-s;
    u2=f-sp;
    relchg=norm(u1-u2,'fro')/norm(u1,'fro');
    ii=ii+1;
    %%%%------------finit diff------------%%%%
    D2s=D2(s);
    D1s=D1(f-s);
    %%%%------------update p--------------%%%%
    p1=p1+1.618*beta1*(D2s-x)';
    p2=p2+1.618*beta2*(s-y)';
    p3=p3+1.618*beta3*(D1s-z)';
end
%%%%--------------Subfunction-------------%%%%
function C=getC(I)
sizeI=size(I);
C.eigsD1tD1=abs(psf2otf([1,-1],sizeI)).^2;  %x-direction
C.eigsD2tD2=abs(psf2otf([1;-1],sizeI)).^2;  %y-direction
end
%%%%--------------Subfunction-------------%%%%
function D1=defDD1t
D1=@(U)ForwardD1(U);
end

function D2=defDD2t
D2=@(U)ForwardD2(U);
end

function Dt=defDDt
Dt= @(X,Y) Dive(X,Y);
end

function Dux=ForwardD1(U)
Dux=[diff(U,1,2),U(:,1)-U(:,end)];
end

function Duy=ForwardD2(U)
Duy=[diff(U,1,1);U(1,:)-U(end,:)];
end

function DtXY = Dive(X,Y)
DtXY = [X(:,end) - X(:, 1), -diff(X,1,2)];
DtXY = DtXY + [Y(end,:) - Y(1, :); -diff(Y,1,1)];
end
end