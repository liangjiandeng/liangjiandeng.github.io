function ration = psnr(ref, sig)

%  ref: the groud-truth signal
%  sig: the modified signal

% if ref and sig in [0,1]
[m, n] = size(ref);

norm2 = norm(ref(:) - sig(:));
norm2 =norm2^2;
ration = 10* log10(m*n/norm2);

%ration = 10*(log10(m*n)-log10(norm(sig(:)-ref(:))^2));
% 
% f: real image 
% f_labda1:restored image


 