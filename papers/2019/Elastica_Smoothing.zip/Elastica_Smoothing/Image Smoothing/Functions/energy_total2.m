function energy  = energy_total2(para, u0, v)

% Engergy equation: Eq. (1)
norm_P    = sqrt(dxf(v).^2 + dyf(v).^2)+eps;  % |grad(v)|=|p|
px1       = dxf(v)./norm_P; % grad_x(v)/|grad(v)|
px2       = dyf(v)./norm_P; % grad_y(v)/|grad(v)|
div_n     = dxc2(px1) + dyc2(px2); % div.(p/|p|)
temp_mid  = (para.aa+para.bb*div_n.^2).*norm_P;
norm2     = (u0 - v).^2;
energy    = 0.5*para.eta*sum(norm2(:)) + sum( temp_mid(:) );
% norm2     = norm(v-u0,'fro')^2;
% energy    = 0.5*para.eta*norm2 + sum( temp_mid(:) );

end


function v=dxf(u)
%   u(i+1,j)       - u(i,j)
v = u([2:end 1],:) - u(:,:);
end

function v=dyf(u)
%   u(i,j+1)       - u(i,j)
v = u(:,[2:end 1]) - u(:,:);
end

function v=dxc2(u)
%   u(i,j) - u(i-1,j)
v = u(:,:) - u([end 1:end-1],:);
end

function v=dyc2(u)
%   u(i,j) - u(i,j-1)
v = u(:,:) - u(:,[end 1:end-1]);
end