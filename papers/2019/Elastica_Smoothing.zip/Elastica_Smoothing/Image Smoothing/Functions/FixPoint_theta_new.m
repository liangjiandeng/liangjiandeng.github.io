% -------------------Fixed Point Iterative METHOD--------------------------
% Point Iteration Example %%
% to find the root of f(x) = x^3 + 5x -5 in [0,1] 
% perform the iteration: x_{n+1} =g(x_{n}) = (5-x^3_{n})/5
% L.J. Deng (UESTC)
% 2017-10-20
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [theta] = FixPoint_theta_new(P13_1, P13_2, lambda13_1, lambda13_2, gamma)

MAX_Iter = 1e+2;
Tol      = 1e-3; %tolerance
count    = 0;
ReEr     = 1;

A        = P13_1.^2 + P13_2.^2;  % X^{T}X
B        = gamma.*(P13_1.*lambda13_1 + P13_2.*lambda13_2); %X^{T}Y

X0       = sqrt(A);  % initial

while count<MAX_Iter && (ReEr > Tol)
    
    TMat = X0.*A + B;
    BMat = sqrt( (X0.*P13_1 + gamma.*lambda13_1).^2 + ...
                 (X0.*P13_2 + gamma.*lambda13_2).^2 ) + eps;
    X1   = TMat./BMat;
    
    ReEr = norm(X1-X0, 'fro');
    X0   = X1;

    count = count + 1;
end
X1(X1<0) = 0;
theta    = X1;

