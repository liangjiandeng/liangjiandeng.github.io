function [N1, N2] = iter_N(P1, P2, N1, ...
              N2, det_A, A11, A12, A21, A22, bb, r4, ...
              M1, M2, lambda41, lambda42, iterNum)
% Iterative solving N
% LJ Deng(UESTC)
% 2017-10-21
    
for k            = 1:iterNum  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    temp_coe = 2*bb*sqrt( aver_xb(P1).^2+aver_yb(P2).^2 ); % 2b*|A|_{i,j}(P)
    c_N = max(max( temp_coe ));   % c = max{2b*|A|_{i,j}(P)}
    diff_c_N = c_N - temp_coe;    % c - 2b*|A|_{i,j}(P)
    
    temp_div = diff_c_N.*( dxb(N1)+dyb(N2) ); % (c - 2b*|A|_{i,j}(P)).*div(n)
    f1 = fftn( r4*M1 - lambda41 - dxf(temp_div) );% r4*M1 - lambda41 - (temp_div(i+1,j)-temp_div(i,j))
    f2 = fftn( r4*M2 - lambda42 - dyf(temp_div) );% r4*M2 - lambda42 - (temp_div(i,j+1)-temp_div(i,j))

    tempA11 = r4-c_N*A11;
    tempA12 =   -c_N*A12;
    tempA21 =   -c_N*A21;
    tempA22 = r4-c_N*A22;
    det_tempA = r4*r4+2*c_N*r4*det_A; 
           
    ff1 = ( tempA22.*f1 - tempA12.*f2)./det_tempA;
    ff2 = (-tempA21.*f1 + tempA11.*f2)./det_tempA;

    N1 = real(ifftn(ff1));
    N2 = real(ifftn(ff2));  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     
end

    
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
function v=aver_xb(u)
%    u(i,j) + u(i-1,j)
v = (u(:,:) + u([end 1:end-1],:))/2;

function v=aver_yb(u)
%    u(i,j) + u(i,j-1)
v = (u(:,:) + u(:,[end 1:end-1]))/2;

function v=dxb(u)
%   u(i,j) - u(i-1,j)
v = u(:,:) - u([end 1:end-1],:);

function v=dyb(u)
%   u(i,j) - u(i,j-1)
v = u(:,:) - u(:,[end 1:end-1]);

function v=dxf(u)
%   u(i+1,j)       - u(i,j)
v = u([2:end 1],:) - u(:,:);

function v=dyf(u)
%   u(i,j+1)       - u(i,j)
v = u(:,[2:end 1]) - u(:,:);




