function [Mat] = fftMat(u0)

 [l1, l2]         = size(u0);
 
% %----FFT pre-processing--------------------
z1p              = -1 + exp( sqrt(-1)*2*pi*[0:l1-1]/l1);  %FFT(S1^{+} - I)
z1n              =  1 - exp(-sqrt(-1)*2*pi*[0:l1-1]/l1);  %FFT(-S1^{-} + I)
z2p              = -1 + exp( sqrt(-1)*2*pi*[0:l2-1]/l2);  %FFT(S2^{+} - I)
z2n              =  1 - exp(-sqrt(-1)*2*pi*[0:l2-1]/l2);  %FFT(-S2^{-} + I)

w1        = cos(2*pi*[0:l1-1]/l1);
w2        = cos(2*pi*[0:l2-1]/l2);
Mat.A11   = repmat(conj(z1p').*conj(z1n'), [1, l2]);
Mat.A12   = conj(z1p')*z2n;
Mat.A21   = conj(z1n')*z2p;
Mat.A22   = repmat(conj(z2p).*conj(z2n), [l1, 1]);
Mat.det_A = repmat(conj(w1'), [1 l2]) + repmat(w2, [l1, 1]) -2;
Mat.B1    = repmat(conj(z1n').*conj(z1p'), [1 l2]);
Mat.B2    = repmat(conj(z2n).*conj(z2p), [l1 1]);

% %----FFT pre-processing--------------------
% z1p              = -1 + exp( sqrt(-1)*2*pi*[1:l1]/l1);  %FFT(S1^{+} - I)
% z1n              =  1 - exp(-sqrt(-1)*2*pi*[1:l1]/l1);  %FFT(-S1^{-} + I)
% z2p              = -1 + exp( sqrt(-1)*2*pi*[1:l2]/l2);  %FFT(S2^{+} - I)
% z2n              =  1 - exp(-sqrt(-1)*2*pi*[1:l2]/l2);  %FFT(-S2^{-} + I)
% 
% % w1        = cos(2*pi*[1:l1]/l1);
% % w2        = cos(2*pi*[1:l2]/l2);
%  w1        = cos(2*pi*[0:l1-1]/l1);
%  w2        = cos(2*pi*[0:l2-1]/l2);
%  
% Mat.A11   = repmat(conj(z1p').*conj(z1n'), [1, l2]);
% Mat.A12   = conj(z1p')*z2n;
% Mat.A21   = conj(z1n')*z2p;
% Mat.A22   = repmat(conj(z2p).*conj(z2n), [l1, 1]);
% Mat.det_A = repmat(conj(w1'), [1 l2]) + repmat(w2, [l1, 1]) -2;
% Mat.B1    = repmat(conj(z1n').*conj(z1p'), [1 l2]);
% Mat.B2    = repmat(conj(z2n).*conj(z2p), [l1 1]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% for i=1:l1    % generate A and Aij matrix for \lambda
%     for j=1:l2
%         
%       A11(i,j)   = z1p(i)*z1n(i);
%       A12(i,j)   = z1p(i)*z2n(j);
%       A21(i,j)   = z2p(j)*z1n(i);
%       A22(i,j)   = z2p(j)*z2n(j);
%       det_A(i,j) = ( cos(2*pi*(i-1)/l1) + cos(2*pi*(j-1)/l2) - 2);
% 
%       B1(i,j)    = z1n(i)*z1p(i);
%       B2(i,j)    = z2n(j)*z2p(j);
%     end
% end

end





