% Demo for the comparisons by different methods
% LJ Deng(UESTC)
% 2017-6-7
%============================
clear all; close all;
addpath(strcat(pwd,'/Utils'));
addpath(strcat(pwd,'/Data'));
addpath(strcat(pwd,'/Metric Code'));
addpath(strcat(pwd,'/Proposed'));


load Pleiades_our_new
m = 512; n = 128;
HRMS                 = HRMS(1:m,1:m,:);
LRMS                  = LRMS(1:n,1:n,:);
PAN                    = PAN(1:m,1:m);
maxval                = max(HRMS(:));
GT                      = rescalefun(HRMS);

%figure,imshow(GT(:,:,[3 2 1]));title('REF');
location              = [160 230 310 410];
showImage4(maxval*GT ,0,22,1,11,0,11,location); title('REF')
I_MS                   = interp23tap(LRMS,4);
%ims                     = rescalefun(I_MS);
showImage4(I_MS ,0,22,1,11,0,11,location);title('LRMS')
showPan2(PAN,0,2, 1,11,location);title('PAN')

PANres                  = rescalefun(PAN);
MSres                   = rescalefun(I_MS);

%% =====Proposed=====
[para] = parasetting(2);  % para for data

para.coef   = [0 0.5 0.5 0]';  % coef: depends on the simulation way
%para.coef  = est_coef_mtf(LRMS, PAN, para.scale); % coef: also could
%estimated by hand (sometimes not accurate)

[Proposed_orig]   = Iter_Fusion_WTVGLp(LRMS, PAN, para, 1);   % original version

Proposed_orig          = rescalefun(Proposed_orig);
[Proposed_orig_Ind]  = index_evaluation(GT, Proposed_orig);
showImage4(maxval*Proposed_orig,0,22,1,11,0,11, location); title('Proposed')


%% ======Proposed(Enhanced version)========
tic
[Proposed]    = Iter_Fusion_WTVGLp(LRMS, PAN, para, 2);  % enhance version by iterations
toc

Proposed          = rescalefun(Proposed);
[Proposed_Ind]  = index_evaluation(GT, Proposed);
showImage4(maxval*Proposed,0,22,1,11,0,11, location); title('Proposed(enhanced)')


%% =========show metrics========
disp('---show metrics---')
disp(['Method',  '                ',  'SAM', '       ',  'ERGAS', '        ',  'Q4'])
disp(['Proposed:  ', '          ',  num2str(Proposed_orig_Ind.SAM), '     ', num2str(Proposed_orig_Ind.ERGAS), '     ', ...
    num2str(Proposed_orig_Ind.Q2n),])

disp(['Proposed(Enhanced):  ', num2str(Proposed_Ind.SAM), '     ', num2str(Proposed_Ind.ERGAS), '     ', ...
    num2str(Proposed_Ind.Q2n),])


