function [output] = rescalefun(input)

[m, n, z] = size(input);
input = double(input);
for i = 1: z
    Img    = input(:,:,i);
    maval(i) = max(Img(:));
    mival(i)  = min(Img(:));
    output(:,:,i) = Img/maval(i);
    
    
end