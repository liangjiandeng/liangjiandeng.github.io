function coef = est_coef_mtf(im_y, PAN,scale)

[m, n, c] = size(im_y);

switch c
    case 4
        MS_LR = im_y;
        %I_P = MTF(PAN,'IKONOS',[],scale);
        I_P = MTF_PAN(PAN,'IKONOS',scale);
        %I_PAN = I_P(1:scale:end,1:scale:end,:);
        I_PAN = imresize(I_P,1/scale,'nearest');

        D1 = MS_LR(:,:,1); D2 = MS_LR(:,:,2);
        D3 = MS_LR(:,:,3); D4 = MS_LR(:,:,4);

        M = [D1(:) D2(:) D3(:) D4(:)];
        pan = I_PAN(:);
        %----------||M*alpha - pan||_{2}^{2}------------
        A = M'*M;
        rho = M'*pan;
        coef = inv(A)*rho;

    case 8
        MS_LR = im_y;
        %I_P = MTF(PAN,'IKONOS',[],scale);
        I_P = MTF_PAN(PAN,'WV2',scale);
        %I_PAN = I_P(1:scale:end,1:scale:end,:);
        I_PAN = imresize(I_P,1/scale,'nearest');
        
        D1 = MS_LR(:,:,1); D2 = MS_LR(:,:,2);
        D3 = MS_LR(:,:,3); D4 = MS_LR(:,:,4);
        D5 = MS_LR(:,:,5); D6 = MS_LR(:,:,6);
        D7 = MS_LR(:,:,7); D8 = MS_LR(:,:,8);
        
        M = [D1(:) D2(:) D3(:) D4(:) D5(:) D6(:) D7(:) D8(:)];
        pan = I_PAN(:);
        %----------||M*alpha - pan||_{2}^{2}------------
        A = M'*M;
        rho = M'*pan;
        coef = inv(A)*rho;
        
end