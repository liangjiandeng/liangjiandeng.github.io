function [Proposed]   = Iter_Fusion_WTVGLp(LRMS, PAN, para, IteNo)
% This is a functio to iteratively solve the given pansharpening model
% LJ Deng (UESTC)
% 2017-6-10
%% ============================
MS_LR                 = LRMS;
hPatch                 = zeros(para.scale*size(LRMS,1), para.scale*size(LRMS,2), size(LRMS,3));
im_l                      = LRMS;
PAN_true             = PAN;

for i = 1:IteNo
    if i==1
        [im_fusion, Re] = Fusion_WTVGLp(MS_LR, PAN, para);
    else
        [im_fusion, ReErr] = Fusion_WTVGLp2(MS_LR, PAN, para);
    end
    hPatch           = hPatch + im_fusion;
    
    %MTFfusion        = MTF(hPatch, 'none', 'WV2', para.scale);  % Rio & QB
    MTFfusion        = MTF(hPatch, 'IKONOS', [], para.scale);  % IKONOS
    %DownError = MTFfusion(1:scale:end,1:scale:end,:);
    DownError        = imresize(MTFfusion, 1/para.scale, 'nearest');
    MS_LR            = im_l - DownError;
    
    patern           = para.coef(1)*hPatch(:,:,1) + para.coef(2)*hPatch(:,:,2)+ para.coef(3)*hPatch(:,:,3) + para.coef(4)*hPatch(:,:,4);
   
%     patern           = para.coef(1)*hPatch(:,:,1) + para.coef(2)*hPatch(:,:,2)+ para.coef(3)*hPatch(:,:,3) + para.coef(4)*hPatch(:,:,4)...
%                         + para.coef(5)*hPatch(:,:,5) + para.coef(6)*hPatch(:,:,6)+ para.coef(7)*hPatch(:,:,7) + para.coef(8)*hPatch(:,:,8);
%  
    PAN              = PAN_true  - patern;


end


Proposed = hPatch;

% project to original domain
Proposed(Proposed <= 0) = 0;  % if pleiades, to [0, 1023]
Proposed(Proposed >=(2^10-1)) =2^10 -1; 






