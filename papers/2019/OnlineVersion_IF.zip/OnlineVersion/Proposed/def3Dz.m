function Dz=def3Dz
Dz=@(U)ForwardDz(U);
end