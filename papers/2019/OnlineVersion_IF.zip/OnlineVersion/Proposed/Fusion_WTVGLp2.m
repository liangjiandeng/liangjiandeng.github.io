function [im_fusion, Re] = Fusion_WTVGLp2(MS, PAN, para)

M                =   interp23tap(MS,4);  % upscale MS_LR by interpolation
%M                = GS(MS, PAN);
P                =   PAN; % duplicate P to get 3D matrix

w                = para.coef';
wT               = w';

%%====Operators========%%
Dx = Ndef3Dx;	DxT = Ndef3DxT;    % up-down direction
Dy = Ndef3Dy;	DyT = Ndef3DyT;
Dz = def3Dz;	DzT = def3DzT;

% Dx = def3Dx;	DxT = def3DxT;    % up-down direction
% Dy = def3Dy;	DyT = def3DyT;
% Dz = def3Dz;	DzT = def3DzT;

filter.x(1,:,:) = 1;      filter.x(2,:,:) = -1;
filter.y(:,1,:) = 1;      filter.y(:,2,:) = -1;
filter.z(:,:,1) = 1;      filter.z(:,:,2) = -1;

Size = size(M);
Dim = length(Size);
eigsDxTDx = abs(psf2otf(filter.x,Size)).^2;
eigsDyTDy = abs(psf2otf(filter.y,Size)).^2;
eigsDzTDz = abs(psf2otf(filter.z,Size)).^2;

consT  = (para.eta1 + para.beta1)*eigsDxTDx + (para.eta2 + para.beta2)*eigsDyTDy...
         + (para.eta3 + para.beta3)*eigsDzTDz + para.r*ones(Size) +  eps;

%%======initial setting=======%%
B1 = (zeros(Size));      B2= (zeros(Size));
B3 = (zeros(Size));      A1 = (zeros(Size));
A2 = (zeros(Size));      A3 = (zeros(Size));

C  = (zeros(Size));

U             = zeros(Size);
%U             = zeros(Size);
V             = zeros(Size);

%%==ADMM to solve the given nonconvex pansharpening problem==%%
ii = 1;
relchg  = 1;
while relchg > para.tol && ii < para.maxitr
    
    
    % ---T1-subproblem
    DxMa   = Dx(U - M);
    for j = 1: Size(3)  % L_{1/2} solving by fast_deconv (2009)
        T1(:,:,j)    = solve_Lp(DxMa(:,:,j) - A1(:,:,j), para.alpha1/para.eta1, para.p);
    end
    %T    = solve_Lp(U - M - A, 1/para.alpha, para.p);
    % ---T2-subproblem
    DyMa   = Dy(U - M);
    for j = 1: Size(3)  % L_{1/2} solving by fast_deconv (2009)
        T2(:,:,j)    = solve_Lp(DyMa(:,:,j) - A2(:,:,j), para.alpha2/para.eta2, para.p);
    end
    % ---T3-subproblem
    DzMa   = Dz(U - M);
    for j = 1: Size(3)  % L_{1/2} solving by fast_deconv (2009)
        T3(:,:,j)    = solve_Lp(DzMa(:,:,j) - A3(:,:,j), para.alpha3/para.eta3, para.p);
    end
    % ---V-subproblem
    V3   = Unfold(V,size(V),3);
    U3   = Unfold(U,size(U),3);
    C3   = Unfold(C,size(C),3);
    P3   = PAN(:)';
    lef  = para.lambda1*wT*w + para.r*eye(size(w,2));
    rig  = para.lambda1*wT*P3 + para.r*U3 - para.r*C3;
    VM   = inv(lef)*rig;
    V    = Fold(VM,size(V),3);
    
    %para.r = 1.05*para.r;  % penalty term, need to increase para.r 
    % ---Xi-subproblems
%     XX1 = Dx(U) - B1;
%         for j = 1: Size(3)  % L_{1/2} solving by fast_deconv (2009)
%         X1(:,:,j)    = solve_Lp(XX1(:,:,j), para.w1/para.beta1, para.p);
%         end
%     XX2 = Dy(U) - B2;
%         for j = 1: Size(3)  % L_{1/2} solving by fast_deconv (2009)
%         X2(:,:,j)    = solve_Lp(XX2(:,:,j), para.w2/para.beta2, para.p);
%         end
%         
%      XX3 = Dz(U) - B3;
%         for j = 1: Size(3)  % L_{1/2} solving by fast_deconv (2009)
%         X3(:,:,j)    = solve_Lp(XX3(:,:,j), para.w3/para.beta3, para.p);
%         end
        
    X1   = wthresh(Dx(U) - B1,'s', para.w1/para.beta1);
    X2   = wthresh(Dy(U) - B2,'s', para.w2/para.beta2);
    X3   = wthresh(Dz(U) - B3,'s', para.w3/para.beta3);

    % ---U-subproblem
    Us   = U;
    R1    = para.eta1*DxT(Dx(M) + T1 + A1) + para.eta2*DyT(Dy(M) +...
                T2 + A2) + para.eta3*DzT(Dz(M) + T3 + A3);
    
    R2    = para.r*(V + C);
            
    R3    = para.beta1*DxT(X1 + B1) + para.beta2*DyT(X2 + B2) + para.beta3*DzT(X3 + B3);
            
    U      = real(ifftn(fftn(R1 + R2 + R3)./consT));

    
    %--- Update Multipliers
    A1    = A1 + 1.618*(T1 - Dx(U  - M));
    A2    = A2 + 1.618*(T2 - Dy(U  - M));
    A3    = A3 + 1.618*(T3 - Dz(U  - M));
    C     = C + 1.618*(V  - U);
    B1    = B1 + 1.618*(X1 - Dx(U));    
    B2    = B2 + 1.618*(X2 - Dy(U));   
    B3    = B3 + 1.618*(X3 - Dz(U));   
    
    %--- Relative Errors
    relchg = norm(Us(:) - U(:),'fro')/norm(U(:),'fro');
    Re.rr(ii)   = relchg;
%     [Q_avg_our, SAM_our, ERGAS_our, SCC_our, Q_our] = indexes_evaluation(U,GT,4,11,32,1,11,0);
%     Re.Q(ii)    = Q_our;
%     Re.SAM(ii)  = SAM_our;
%     Re.ERGAS(ii)= ERGAS_our;
%     Re.SCC(ii)  = SCC_our;

    ii=ii+1;   
    %--- Increase ration
    %para.alpha = 2.8*para.alpha;
end

im_fusion = U;
