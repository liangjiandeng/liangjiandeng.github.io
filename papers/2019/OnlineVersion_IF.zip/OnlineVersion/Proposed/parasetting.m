function [para] = parasetting(type)    

%% =====Para setting========
switch type
    case 1   % sichuan dataset (IKONOS)
            para.p             = 0.5;
            para.alpha1     = 0.005; 
            para.alpha2     = 0.005; 
            para.alpha3     = 10; 
            para.lambda1  = 0.5;
            para.r              = 1e-3;
            para.w1           = 1e-2;
            para.w2           = 1e-2;
            para.w3           = 1e-2;
            para.eta1         = 5e-3;
            para.eta2         = 5e-3;
            para.eta3         = 1e-3;
            para.beta1       = 1e-2;
            para.beta2       = 1e-2;
            para.beta3       = 1e-2;
            para.tol            = 1e-8;
            para.maxitr      = 100;
            para.scale        = 4;

    case 2   % pleiades dataset (IKONOS), could be better with tuned para
            para.p             = 0.5;
            para.alpha1        = 0.005; 
            para.alpha2        = 0.005; 
            para.alpha3        = 20; 
            para.lambda1       = 0.05;
            para.r             = 1e-3;
            para.w1            = 1e-2;
            para.w2            = 1e-2;
            para.w3            = 1e-2;
            para.eta1          = 5e-3;
            para.eta2          = 5e-3;
            para.eta3          = 1e-3;
            para.beta1         = 1e-2;
            para.beta2         = 1e-2;
            para.beta3         = 1e-2;
            para.tol           = 1e-8;
            para.maxitr        = 100;
            para.scale         = 4;

     case 3   % rio (WV2)
            para.p             = 0.5;
            para.alpha1        = 0.005; 
            para.alpha2        = 0.005; 
            para.alpha3        = 30; 
            para.lambda1       = 0.01;
            para.r             = 1e-3;
            para.w1           = 1e-2;
            para.w2           = 1e-2;
            para.w3           = 1e-2;
            para.eta1         = 5e-3;
            para.eta2         = 5e-3;
            para.eta3         = 1e-3;
            para.beta1       = 1e-2;
            para.beta2       = 1e-2;
            para.beta3       = 1e-2;
            para.tol            = 1e-8;
            para.maxitr      = 100;
            para.scale        = 4;
end