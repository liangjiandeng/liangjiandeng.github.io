% This is a simple script for image inpainting using the proposed new
% priority definition
% by L. -J. Deng (UESTC)
% email: liangjian1987112@126.com
%% ============= set path===============
clear all;close all
addpath('TestImages');  % all images appearing in the paper
addpath('utilities');
%%---------------------------
ww = 'zebra';   % choose the name of test image (refer to the TestImages)
dirTe = strcat('TestImages\', ww, '1.png');
dirTe2 = strcat('TestImages\', ww, '.png');
%color = [255 0 0];  % if the target region is red color
 color = [0 255 0];  % if the target region is green color
%%--- Main function
%the proposed method
    [i1,i2,i3,c,d,t,mov,conf,deta]=inpaintNewDefi(dirTe2,dirTe, color);  
%Criminisi's method ``04'TIP''
    %[i1,i2,i3,c,d,t,mov,conf,deta]=inpaint(dirTe2,dirTe, color);  %
%% ============= present results============%
figure;
subplot(131);imshow(uint8(i2)); title('Original image');
subplot(132);imshow(uint8(i3)); title('Fill region');
subplot(133);imshow(uint8(i1)); title('Inpainted image');
%ent=rectangleonimage(pic,sw,n,c, scale)
display('------------------------------------------------')
display(['Total time','    ',num2str(t(1)+t(2)+t(3)+t(4)+t(5))])
display('--------------   RESULTS TABLE   --------------')
display('Ready phase  | Compute gradient  |Get the priorities  |  Get the exemplars  | Update and copy ')
display([num2str(t(4)), '                ',num2str(t(5)), '               ',num2str(t(1)), '                      ', num2str(t(2)), '                      ', num2str(t(3))])
