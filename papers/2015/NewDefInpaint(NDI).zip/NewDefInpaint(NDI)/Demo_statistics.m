% Make a statistics for the new definition of priority
% L.-J Deng (UESTC)
% visiting at CWRU, USA
% 02/02/2014
%%--------------------%%
clear all; close all;
% please download test_set3 (im2gps) from:
% http://graphics.cs.cmu.edu/projects/im2gps/
files = dir('test_set3\*.jpg'); 
leng = length(files);
type = 2;
rho = 1;
%============== start statistics ==============%
for i = 1:leng
    % load inpainted images
    aa = strcat('test_set3\',files(i).name); 
    I = imread(aa);
    grayIm = rgb2gray(I);
    E = edge(grayIm, 'canny');%prewitt; canny;
    % create mask
    switch type
        case 1
            zihu = aa(10:end-4);
            haha = aa(end-3:end);
            bb = strcat('test_set2\',zihu,'_mask',haha);
            Imask = imread(bb);
            II = Imask(:,:,1);
            Mask = logical(II);
        case 2
            [m, n] = size(E);
            x1 = floor(2*m/5); x2 = floor(4*m/5);
            y1 = floor(2*n/5);  y2 = floor(4*n/5);
            Mask = zeros(m, n);
            Mask(x1:x2, y1:y2) = 1;
            Mask = logical(Mask);
    end
    % compute rations
    interEdge = E.*Mask;
    interRate(i) = rho*nnz(interEdge)/nnz(Mask);

    outerEdge = E.*(~Mask);
    outerRate(i) = rho*nnz(outerEdge)/nnz(~Mask);
    
    rationErr(i) = abs(outerRate(i) - interRate(i));  
end
   interMean = mean(interRate);
   outerMean = mean(outerRate);
%============== display =======================%
figure,
    plot([1:leng], interRate, '*b-');
    hold on
    plot([1:leng], outerRate, '*r-');
    hold on
    plot([1:leng], rationErr, '*k-');
    legend('interRate', 'outerRate', 'rationErr', 3)
    xlabel('number of test images')
    ylabel('rate')
    title(['interMean:', num2str(interMean), '----outerMean:', num2str(outerMean)])
figure,
    plot([1:leng], interRate, '*b-');
    hold on
    plot([1:leng], outerRate, '*r-');
    legend('interRate', 'outerRate',2)
    xlabel('number of test images')
    ylabel('rate')
    title(['interMean:', num2str(interMean), '----outerMean:', num2str(outerMean)])
% semilogy plot
figure,
    semilogy([1:leng], interRate, '*b-');
    hold on
    semilogy([1:leng], outerRate, '*r-');
    legend('interRate', 'outerRate',2)
    xlabel('number of test images')
    ylabel('rate')
    title(['interMean:', num2str(interMean), '----outerMean:', num2str(outerMean)])


