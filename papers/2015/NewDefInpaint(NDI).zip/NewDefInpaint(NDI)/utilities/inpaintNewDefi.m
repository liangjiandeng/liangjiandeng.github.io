% This function partly provided by Sooraj Bhat, Modified by Marcel Davey & John Gu
% According to the new priority definition, we add the function
% 'findstep','getbigpatch' and 'newbestexemplar'
% and change the priority definition in the lines 86-90
% L. -J. Deng (UESTC)
% email: liangjian1987112@126.com
%% =============================
function [inpaintedImg,origImg,fillImg,C,D,t,fillMovie,ConfMovie,DetaMovie] = inpaint3(imgFilename,fillFilename,fillColor)
%INPAINT  Exemplar-based inpainting.
% Usage:   [inpaintedImg,origImg,fillImg,C,D,fillMovie] ...
%                = inpaint(imgFilename,fillFilename,fillColor)
% Inputs: 
%   imgFilename    Filename of the original image.
%   fillFilename   Filename of the image specifying the fill region. 
%   fillColor      1x3 RGB vector specifying the color used to specify
%                  the fill region.
% Outputs:
%   inpaintedImg   The inpainted image; an MxNx3 matrix of doubles. 
%   origImg        The original image; an MxNx3 matrix of doubles.
%   fillImg        The fill region image; an MxNx3 matrix of doubles.
%   C              MxN matrix of confidence values accumulated over all iterations.
%   D              MxN matrix of data term values accumulated over all iterations.
%   fillMovie      A Matlab movie struct depicting the fill region over
%   time: t
%------------------------------------------------------------------------
t1=0; t2=0; t3=0; t4=0; t5=0;
tic
warning off MATLAB:divideByZero
[img,fillImg,fillRegion] = loadimgs(imgFilename,fillFilename,fillColor);
img = double(img);
origImg = img;
ind = img2ind(img);
sz = [size(img,1) size(img,2)];
sourceRegion = ~fillRegion;
imwrite(uint8(255*sourceRegion),'_mask.png','PNG');
  
 teststep = findstep(imgFilename, sourceRegion, 9); % automatically estimate steps
% Initialize isophote values
[Ix(:,:,3) Iy(:,:,3)] = gradient(img(:,:,3));
[Ix(:,:,2) Iy(:,:,2)] = gradient(img(:,:,2));
[Ix(:,:,1) Iy(:,:,1)] = gradient(img(:,:,1));
Ix = sum(Ix,3)/(3*255); Iy = sum(Iy,3)/(3*255);
temp = Ix; Ix = -Iy; Iy = temp;  % Rotate gradient 90 degrees

% Initialize confidence and data terms
C = double(sourceRegion);
D = repmat(-.1,sz);
iter = 1;

t4=toc;
% Visualization stuff
if nargout==9
  fillMovie(1).cdata=uint8(img); 
  fillMovie(1).colormap=[]; 
  E(:,:,1)=C;E(:,:,2)=C;E(:,:,3)=C;
  ConfMovie(1).cdata=uint8(255*E);
  ConfMovie(1).colormap=[];
  F(:,:,1)=D;F(:,:,2)=D;F(:,:,3)=D;
  DetaMovie(1).cdata=uint8(255*F);
  DetaMovie(1).colormap=[];
  origImg(1,1,:) = fillColor;
  iter = 2;
end

rand('state',0);

% Loop until entire fill region has been covered
while any(fillRegion(:))  
 tic
  % Find contour & normalized gradients of fill region
  fillRegionD = double(fillRegion); 
  dR = find(conv2(fillRegionD,[1,1,1;1,-8,1;1,1,1],'same')>0); 
 
  [Nx,Ny] = gradient(double(~fillRegion)); 
  N = [Nx(dR(:)) Ny(dR(:))];    
  N = normr(N);  
  N(~isfinite(N))=0; % handle NaN and Inf
  
t5 = t5 +toc;
  % Compute confidences along the fill front
tic
  for k=dR'  Hp = getpatch(sz,k); q = Hp(~(fillRegion(Hp))); C(k) = sum(C(q))/numel(Hp);  end
  
  % Compute patch priorities = confidence term * data term
  D(dR) = abs(Ix(dR).*N(:,1)+Iy(dR).*N(:,2)) + 0.001;  %data term
  if (iter<teststep)      % for the new priority definition
      priorities = D(dR);
  else
      priorities = C(dR);
  end
t1 = t1 +toc;
  % Find patch with maximum priority, Hp
  
tic
  [unused,ndx] = max(priorities(:));
  p = dR(ndx(1));
  [Hp,rows,cols] = getpatch(sz,p);
  toFill = fillRegion(Hp);
  
  [Ep,erows,ecols,w] = getbigpatch(sz,p, imgFilename);
  sRegion = sourceRegion(Ep)';
  
  bigpatchimg = img(erows,ecols,:);
  
  % Find exemplar that minimizes error, Hq   %  ������ģ��
  Hq = newbestexemplar(bigpatchimg,img(rows,cols,:),toFill',sRegion,sz,p,w);

  t2 = t2 +toc;
  % Update fill region
tic
  toFill = logical(toFill);                 % Marcel 11/30/05
  fillRegion(Hp(toFill)) = false;
  
  % Propagate confidence & isophote values
  C(Hp(toFill))  = C(p);
  Ix(Hp(toFill)) = Ix(Hq(toFill));
  Iy(Hp(toFill)) = Iy(Hq(toFill));
  
  % Copy image data from Hq to Hp
  ind(Hp(toFill)) = ind(Hq(toFill));  %ճ����ȥ
  img(rows,cols,:) = ind2img(ind(rows,cols),origImg);  
  
t3 = t3 +toc;
  % Visualization stuff
  if nargout==9
    ind2 = ind;
    ind2(logical(fillRegion)) = 1;          % Marcel 11/30/05
    %ind2(fillRegion) = 1;                  % Original
    fillMovie(iter).cdata=uint8(ind2img(ind2,origImg)); 
    fillMovie(iter).colormap=[];
    E(:,:,1)=C;E(:,:,2)=C;E(:,:,3)=C;
    ConfMovie(iter).cdata=uint8(255*E);
    ConfMovie(iter).colormap=[];
    F(:,:,1)=D;F(:,:,2)=D;F(:,:,3)=D;
    DetaMovie(iter).cdata=uint8(255*F);
    DetaMovie(iter).colormap=[];
  end

  iter = iter+1;
end
m2 = cputime;
inpaintedImg=img;


t=[t1;t2;t3;t4;t5];

%---------------------------------------------------------------------
function Hq = bestexemplar(img,Ip,toFill,sourceRegion)
m=size(Ip,1); mm=size(img,1); n=size(Ip,2); nn=size(img,2);
best = bestexemplarhelper(mm,nn,m,n,img,Ip,toFill,sourceRegion);
Hq = sub2ndx(best(1):best(2),(best(3):best(4))',mm);

%  to get the new exemplar with patch-in-patch method
function Hq = newbestexemplar(img,Ip,toFill,sourceRegion,sz,p,w)
m=size(Ip,1); mm=size(img,1); n=size(Ip,2); nn=size(img,2);
best = bestexemplarhelper(mm,nn,m,n,img,Ip,toFill,sourceRegion);

g(2) = fix(p/sz(1))+1; g(1) = mod(p,sz(1));

 if (g(1)<w+1)&(g(2)<w+1)
     best(1) = best(1); best(2) = best(1)+8;
     best(3) = best(3); best(4) = best(3)+8;
 elseif (g(1)<w+1)&(w+1<=g(2))
     best(1) = best(1); best(2) = best(1)+8;
     best(3) = g(2)+best(3)-(w+1);  best(4) = best(3)+8;
 elseif (w+1<=g(1))&(g(2)<w+1)
     best(1) = g(1)+best(1)-(w+1);  best(2) = best(1)+8;
     best(3) = best(3); best(4) = best(3)+8;
 else
     best(1) = g(1)+best(1)-(w+1);  best(2) = best(1)+8;
     best(3) = g(2)+best(3)-(w+1);  best(4) = best(3)+8;
 end
     
Hq = sub2ndx(best(1):best(2),(best(3):best(4))',sz(1));
%---------------------------------------------------------------------
% Returns the indices for a 9x9 patch centered at pixel p.
%---------------------------------------------------------------------
function [Hp,rows,cols] = getpatch(sz,p)
% [x,y] = ind2sub(sz,p);  % 2*w+1 == the patch size
w=4; p=p-1; y=floor(p/sz(1))+1; p=rem(p,sz(1)); x=floor(p)+1;
rows = max(x-w,1):min(x+w,sz(1));
cols = (max(y-w,1):min(y+w,sz(2)))';
Hp = sub2ndx(rows,cols,sz(1));


% patch-in-patch to get bigger patch
function [Ep,erows,ecols,w] = getbigpatch(sz,p, Filename)
if (strcmp(Filename, 'TestImages\ball.png') ||...
    strcmp(Filename, 'TestImages\green.png')||...
    strcmp(Filename, 'TestImages\erie.png'))
    w = 70;
elseif strcmp(Filename, 'TestImages\sky.png')
    w = 40;
else 
    w = 30;
end
% [x,y] = ind2sub(sz,p);  % 2*w+1 == the patch size
p=p-1; y=floor(p/sz(1))+1; p=rem(p,sz(1)); x=floor(p)+1;
erows = max(x-w,1):min(x+w,sz(1));
ecols = (max(y-w,1):min(y+w,sz(2)))';
Ep = sub2ndx(erows,ecols,sz(1));

%---------------------------------------------------------------------
function N = sub2ndx(rows,cols,nTotalRows)
X = rows(ones(length(cols),1),:);
Y = cols(:,ones(1,length(rows)));
N = X+(Y-1)*nTotalRows;

%---------------------------------------------------------------------
function img2 = ind2img(ind,img)
for i=3:-1:1, temp=img(:,:,i); img2(:,:,i)=temp(ind); end;

%---------------------------------------------------------------------
function ind = img2ind(img)
s=size(img); ind=reshape(1:s(1)*s(2),s(1),s(2));

%---------------------------------------------------------------------
function [img,fillImg,fillRegion] = loadimgs(imgFilename,fillFilename,fillColor)
img = imread(imgFilename); fillImg = imread(fillFilename);
fillRegion = fillImg(:,:,1)==fillColor(1) & ...
    fillImg(:,:,2)==fillColor(2) & fillImg(:,:,3)==fillColor(3);

