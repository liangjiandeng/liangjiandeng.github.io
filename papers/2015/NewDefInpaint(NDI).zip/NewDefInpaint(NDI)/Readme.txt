Please run:
           Demo.m   
    for the impletation of ``Exemplar-Based Image Inpainting Using A Modified Priority Definition''
 %------------------------------------------------------%
1. For the experiments of different test images, you can change the name of ``ww'' according to the            image names in the folder ``TestImages''

2. For the statistci analysis, please run:
          Demo_statistics.m
    but you should first download the dataset ``test_set3 (im2gps)'' from:
          http://graphics.cs.cmu.edu/projects/im2gps/

3. ``TestImages'' contains all test images appearing in the paper.