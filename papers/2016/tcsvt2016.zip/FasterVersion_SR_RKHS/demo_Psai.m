% Applied RKHS_imSR to patch class
% Liang-Jian Deng (UESTC)
% June 26,2014 at CWRU

clear all; close all;
addpath('functions');
addpath('testimages');
addpath('testimages\1_High');addpath('testimages\1_Low');
addpath('testimages\2_High');addpath('testimages\2_Low');


% [im_true, map] = imread('1_High\infra2.jpg');
 im_true = imread('head-high.bmp');
 im_true = im_true(1:280,1:280,:);
 imwrite(im_true, 'gnd.bmp', 'BMP');
 im_l = imresize(im_true,[140,140], 'bicubic');
 imwrite(im_l, 'input.bmp', 'BMP');
%   im_l = imread('1_Low\infra2_L.jpg');  
%   im_l = im_l(1:110,1:110,:);
type = 2;
%type = input('type=1: RGB channel; type=2: Y channel; please input: type = ');

% set parameters
patch_size = 6;
overlap = 1;                      % the more overlap the better (patch size 5x5)
scale = 2;                       % scaling factor, depending on the trained dictionary
maxIter = 20;

switch type
    case 1
%===========independent channel=============%
im_l = double(im_l);
tic
[im_h_y(:,:,1), im_h_t(:,:,1), im_h_k(:,:,1), im_h_e(:,:,1)]  = admm_patchsr(im_l(:,:,1), scale, overlap, patch_size);
[im_h_y(:,:,2), im_h_t(:,:,2), im_h_k(:,:,2), im_h_e(:,:,2)]   = admm_patchsr(im_l(:,:,2), scale, overlap, patch_size);
[im_h_y(:,:,3), im_h_t(:,:,3), im_h_k(:,:,3), im_h_e(:,:,3)]   = admm_patchsr(im_l(:,:,3), scale, overlap, patch_size);
toc
% im_h_y1 = im_h_y + 1*im_h_e;
% %--back projection------%
im_h_back(:,:,1) = backprojection(im_h_y(:,:,1), im_l(:,:,1), maxIter);
im_h_back(:,:,2) = backprojection(im_h_y(:,:,2), im_l(:,:,2), maxIter);
im_h_back(:,:,3) = backprojection(im_h_y(:,:,3), im_l(:,:,3), maxIter);

II = imresize(im_l,scale);
figure, 
subplot(2,3,1); imshow(im_h_y/255); title('our')
subplot(2,3,2); imshow(II/255); title('bicubic')
subplot(2,3,3); imshow(im_l/255); title('LR')
subplot(2,3,4); imshow(im_h_t/255); title('Td')
subplot(2,3,5); imshow(im_h_k/255); title('Kc')
subplot(2,3,6); imshow(im_h_e/255); title('Pbeta')

figure,
subplot(1,2,1); imshow(im_h_y/255)
subplot(1,2,2); imshow(im_h_back/255)
%========YUV===============%
% change color space, work on illuminance only
    case 2
            im_ycbcr = rgb2ycbcr(im_l);
            im_y = im_ycbcr(:, :, 1);
            im_y = double(im_y);
            im_cb = im_ycbcr(:, :, 2);
            im_cr = im_ycbcr(:, :, 3);

% image SR using Heviside 
tic
          [im_h, im_h_t(:,:,1),  im_h_k(:,:,1), im_h_e(:,:,1)]  = admm_patchsr(im_y, scale, overlap, patch_size);
          %im_h1 = tvdenoise(im_h1,0.3); 
toc

% %-----------------------end -------------------------
% figure, imshow(im_h_back/255)
[nrow, ncol] = size(im_h);
im_h_cb = imresize(im_cb, [nrow, ncol], 'bicubic');
im_h_cr = imresize(im_cr, [nrow, ncol], 'bicubic');

im_h_ycbcr = zeros([nrow, ncol, 3]);
im_h_ycbcr(:, :, 1) = im_h;   %  Our results
im_h_ycbcr(:, :, 2) = im_h_cb;
im_h_ycbcr(:, :, 3) = im_h_cr;
im_h_y = ycbcr2rgb(uint8(im_h_ycbcr));


II = imresize(im_l,scale);
im_h_t = uint8(im_h_t);
im_h_k = uint8(im_h_k);
im_h_e = uint8(im_h_e);

end


imwrite(im_h_y,'our.bmp','BMP')

%---------Display & Quantitative results---------%
im_tt = rgb2ycbcr(im_true);
im_t1 = double(im_tt(:,:,1))/255;

im_tt = rgb2ycbcr(im_h_y); %  our reuslt to yuv channel
im_t2 = double(im_tt(:,:,1))/255;

im_bi = rgb2ycbcr(II); %  our reuslt to yuv channel
im_t3 = double(im_bi(:,:,1))/255;

psnr_our = psnr(im_t1, im_t2);
psnr_bi = psnr(im_t1, im_t3);

figure,
subplot(2,2,1); imshow(im_l); title('low-resolution')
subplot(2,2,2);imshow(im_true); title('true')
subplot(2,2,3); imshow(II); title(['bicubic, PSNR=',num2str(psnr_bi)])
subplot(2,2,4); imshow(im_h_y); title(['our, PSNR=',num2str(psnr_our)])


%ent_y1=rectangleonimage(im_h_y1,[20 70 1 60],1, 3, 2);
%ent_bi=rectangleonimage(II,[20 70 1 60],1, 3, 2);


