function   [c, d, beta] = admm_patch_revise(T, K, P, y, Matrix, para)
% using admm method to solve coefficient c, d, beta
% model:
% min ||y - Td - Kc - P*beta||^2 +lambdac'Kc + alpha|beta|

%=====initial setting==========%
r = para.r;
lambda = para.lambda;
alpha = para.alpha;

[m1, n1] =  size(T);
[m2, n2] =  size(K);
[m3, n3] =  size(P);
    
b = zeros(n3,1);
beta = zeros(n3,1);
u = zeros(n3,1);

y = y(:);
for i = 1: 10
%=====c, d, beta subproblems=====%
% model:
% min ||y - Kc - Td -P*beta||^2 +lambda*c'Kc + r/2||u - beta  + b||^2
    %====== solve c ================%
    a1 = P'*y + r*(u + b);
    a2 = Matrix.A7*a1;
    a3 = K'*y;
    a4 = Matrix.A8*a1;
    a5 = T'*y;
    c1 = a3 - a2;
    c2 = a5 - a4;
    
    w1 = c1 - Matrix.B3*c2;
      c = Matrix.A5*w1;
    %====== solve d ================%
    w2 = c2 - Matrix.A2*c;
      d = Matrix.invB2*w2;
    %====== solve beta ================%
     w3 =  P'*y + r*(u+b) - Matrix.A3*c - Matrix.A4*d;
     beta = Matrix.A9*w3;
     
%=====u subproblem=====%
% model:
% min alpha|u| +r/2||u - beta + b||^2
% u = shrink(beta - b, alpha/r)

p1 = sign(beta - b);
p2 = abs(beta - b);
u = p1.*max(p2 - alpha/r, 0);
%===== update =============%

b  = b + 1.1*(u - beta);

end


