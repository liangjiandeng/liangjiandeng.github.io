function [T, K, TT, KK] = consTM_2d(n, N, m, dd)


    n_grid = sqrt(n);
    N_grid = sqrt(N);
   %----------coarse grid--------%
   %t = 0 + [1:n]/n;
    %t = [1:n_grid]'/n_grid;
    t = [0:(n_grid-1)]'/(n_grid-1);
    %t = [0:(n_grid-1)]'/n_grid;
    
    X = repmat(t,n_grid,1);
    Y = [];

    for i = 1:n_grid
        e = repmat(t(i), n_grid,1);
        Y = [Y; e];
    end

    %------fine grid--------------
    %tt = [1:N_grid]'/N_grid;
    tt = [0:(N_grid-1)]'/(N_grid-1);
    %tt = [0:(N_grid-1)]'/N_grid;
    
    XX = repmat(tt,N_grid,1);
    YY = [];

    for i = 1:N_grid
        ee = repmat(tt(i), N_grid,1);
        YY = [YY; ee];
    end

     % get the matrix T, where T is from function: t^(v-1)/(v-1)!

     M = nchoosek(dd+m-1,dd);
     
     type = m-1;
     T = consT(M, X, Y, type);
     TT = consT(M, XX, YY, type);

     % get the matrix K, where K is from Em(s,t), and
     
     
     if (mod(2*m-dd,2) == 0)
         theta = (-1)^(dd/2+1+m)/(2^(2*m-1)*(pi)^(dd/2)*factorial(m-1)*factorial(m-dd/2));
     end
    

     tic
     % economical version for K and KK   % Nov 25, 2013
     repX = repmat(X,1,n);
     repY = repmat(Y,1,n);
     a = repX - repX';
     b = repY - repY';
     tao = sqrt(a.^2 + b.^2);
     tao(find(tao==0)) = eps;
     K = theta*tao.^(2*m-dd).*log(tao);
     
     repXX = repmat(XX,1,n);
     repYY = repmat(YY,1,n);
     rep1 = repmat(X', N,1);
     rep2 = repmat(Y',N,1);
     
     aa = repXX - rep1;
     bb = repYY - rep2;
     ta = sqrt(aa.*aa + bb.*bb);
     ta(find(ta==0)) = eps;
     KK = theta*ta.^(2*m-dd).*log(ta);
     toc
    
     
     
     
     
     % computation heavy version!!!  before Nov 25,2013
%           tic
%      for j = 1:n
%          %=====construct K=======%
%          a = X - X(j);
%          b = Y - Y(j);
%          tao(:,j) = sqrt(a.^2 + b.^2);   %tao(j,j) = eps;
%          g = find(tao(:,j)==0);
%          tao(g,j) = eps;
%          K(:,j) = theta*tao(:,j).^(2*m-dd).*log(tao(:,j));
%          K(g,j) = 0;
%          
%          %===== construct KK =========%
%          aa = XX - X(j);
%          bb = YY - Y(j);
%          ta(:,j) = sqrt(aa.^2 + bb.^2);   %tao(j,j) = eps;
%          gg = find(ta(:,j)==0);
%          ta(gg,j) = eps;
%          KK(:,j) = theta*ta(:,j).^(2*m-dd).*log(ta(:,j));
%          KK(gg,j) = 0;
%          
%          
%      end
%     toc
%      
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     

     
     
   