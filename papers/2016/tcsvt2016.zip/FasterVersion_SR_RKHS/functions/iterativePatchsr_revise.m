function [hPatch, hPatch1, hPatch2, hPatch3] = iterativePatchsr_revise(T, TT, K, KK, P, PP, mPatch, Matrix, para, scale)
% Applied RKHS_imSR to patch class
% Liang-Jian Deng (UESTC)
% June 26,2014 at CWRU

y = mPatch;
[row_l, col_l] = size(mPatch);
size_h = scale*row_l;
hPatch = zeros(size_h);
hPatch1 = zeros(size_h);
hPatch2 = zeros(size_h);
hPatch3 = zeros(size_h);

for i = 1:1
     %==========old=======
     [c, d, beta] = admm_patch_revise(T, K, P, y, Matrix, para);
     %beta2 = ksparse(beta2, 0.4);
     Pat1 = TT*d;
     Pat2 = KK*c;  
     Pat3 = PP*beta;
     Pat = Pat1 + Pat2 + Pat3;     %  combine patch
     %Pat = Pat1 + conv2(Pat2, p, 'same') ;     %  combine patch
     %Pat = Pat1 + tvdenoise(Pat2,0.3);  %  TV denoise
     Patch(:,:,i) = reshape(Pat, size_h, size_h);
     Patch1(:,:,i) = reshape(Pat1, size_h, size_h);
     Patch2(:,:,i) = reshape(Pat2, size_h, size_h);
     Patch3(:,:,i) = reshape(Pat3, size_h, size_h);
     
     hPatch = hPatch + Patch(:,:,i);
     %hPatch = hPatch + conv2(Patch(:,:,i), p, 'same');
     hPatch1 = hPatch1 + Patch1(:,:,i) ;
     hPatch2 = hPatch2 + Patch2(:,:,i) ;
     hPatch3 = hPatch3 + Patch3(:,:,i) ;

     im_l_s = imresize(hPatch, [row_l, col_l], 'bicubic');
     y = mPatch - im_l_s;

   end

     

end



     