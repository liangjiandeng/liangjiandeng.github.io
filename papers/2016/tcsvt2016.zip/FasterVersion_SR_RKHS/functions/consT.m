function T = consT(M, x, y, type)
% construct the T matrix according to the number of order


n = size(x, 1);
switch type
    case 1
    % pha1 = 1, pha2 = x, pha3 = y
    
%     g1 = 8.*x - 8.*y - 2;
%     k1= erf(g1);
%     g2 = 8.*x -4;
%     k2= erf(g2);
%     g3 = -(8.*x -4).^2;
%     k3= erf(g3);   
%     T = [ones(n,1) x  y  k1  k2  k3];
    
        T = [ones(n,1) x  y];
        
    case 2
     % pha1 = 1, pha2 = x, pha3 = y,
     % pha4 = xy, pha5 =x^2, pha6 = y^2
        T = [ones(n,1)  x  y  x.*y  x.^2  y.^2];
        
    case 3
      % pha1 = 1, pha2 = x, pha3 = y,
     % pha4 = xy, pha5 =x^2, pha6 = y^2
     % pha7=x^2*y, pha8=x*y^2, pha9=x^3, pha10=y^3
        T = [ones(n,1)  x  y  x.*y  x.^2  y.^2  (x.^2).*y...
            x.*(y.^2)   x.^3   y.^3];
        
     case 4
     % pha1 = 1, pha2 = x, pha3 = y,
     % pha4 = xy, pha5 =x^2, pha6 = y^2
     % pha7=x^2*y, pha8=x*y^2, pha9=x^3, pha10=y^3
     % pha11=x^3*y, pha12=x*y^3, pha13=x^2*y^2, pha14=x^4,
     % pha15=y^4,
        T = [ones(n,1)  x  y  x.*y  x.^2  y.^2  (x.^2).*y...
            x.*(y.^2)   x.^3   y.^3  (x.^3).*y  x.*(y.^3)  (x.^2).*(y.^2)...
            x.^4  y.^4];
        
    case 5
    % pha1 = 1, pha2 = x, pha3 = y,
    % pha4 = xy, pha5 =x^2, pha6 = y^2
    % pha7=x^2*y, pha8=x*y^2, pha9=x^3, pha10=y^3
    % pha11=x^3*y, pha12=x*y^3, pha13=x^2*y^2, pha14=x^4,
    % pha15=y^4, pha16=x*y^4,pha17=x^2*y^3,pha18=x^3*y^2
    % pha19=x^4*y, pha20=x^5, pha21=y^5
            T = [ones(n,1)  x  y  x.*y  x.^2  y.^2  (x.^2).*y...
            x.*(y.^2)   x.^3   y.^3  (x.^3).*y  x.*(y.^3)  (x.^2).*(y.^2)...
            x.^4  y.^4  x.*(y.^4)  (x.^2).*(y.^3)   (x.^3).*(y.^2)...
            (x.^4).*y   x.^5   y.^5];

end
        
