function [im_h_y, im_h_t, im_h_k, im_h_e] = admm_patchsr(im_y, scale, overlap, patch_size)
% Applied RKHS_imSR to patch class
% Liang-Jian Deng (UESTC)
% June 26,2014 at CWRU

mIm = im_y;

[h, w] = size(mIm);   % size of LR
size_low = patch_size; % patch size of LR
overlap_low = overlap;  %  overlap of LR

H = scale*h; W = scale*w;  % size of HR
size_h = scale*patch_size; % patch size of LR
overlap_h = scale*overlap; % overlap of HR

% prepared for computing beta
n = size_low*size_low;
 [T, K, TT, KK] = consTM_2d_arbDim(size_low, size_low, size_h, size_h, 3, 2);
 [P, PP] = consP_2d_arbDim(size_low, size_low, size_h, size_h,1e-4, 12);
 [mm1, nn1] = size(T);
 [mm2, nn2] = size(P);
 
%====setting (before)=====
% para.r = 1e-2;
% para.lambda = 1e-11;
% para.alpha = 1e-4;
% 
% A = [K'*K+2*para.lambda*K  K'*T  K'*P; T'*K   T'*T   T'*P; P'*K   P'*T   P'*P+para.r*eye(nn2)];
% invA = inv(A);

%====setting (after)=====
para.r = 1e-3;  %default:para.r = 1e-5;para.lambda = 1e-11;para.alpha = 1e-4;
para.lambda = 1e-11;
para.alpha = 1e-4;

Matrix.A9 = inv(P'*P+para.r*eye(nn2));  % 
Matrix.A1 = (K'*K+2*para.lambda*K) - K'*P*Matrix.A9*P'*K;
Matrix.A2 = T'*K - T'*P*Matrix.A9*P'*K;
Matrix.B1 = K'*T - K'*P*Matrix.A9*P'*T;
Matrix.B2 = T'*T - T'*P*Matrix.A9*P'*T;
Matrix.B3 = Matrix.B1*inv(Matrix.B2);  % B1*inv(B2)
Matrix.invB2 = inv(Matrix.B2);
Matrix.A7 = K'*P*Matrix.A9;
Matrix.A8 = T'*P*Matrix.A9;
Matrix.A3 = P'*K;
Matrix.A4 = P'*T;
Matrix.A5 = inv(Matrix.A1 - Matrix.B3*Matrix.A2);

% set patch indexs 
%---- LR indexs ---------
gridy = 1:size_low - overlap_low : w-(mod(w,size_low-overlap_low)+1+size_low-overlap_low);
gridy = setdiff(gridy, [(w-size_low+1):w]);  % delete rest elements
gridx = 1:size_low - overlap_low: h-(mod(h,size_low-overlap_low)+1+size_low-overlap_low);
gridx = setdiff(gridx, [(h-size_low+1):h]); % delete rest elements
%---- HR indexs ---------
Gridy = 1:size_h - overlap_h : W-(mod(W,size_h-overlap_h)+1+size_h-overlap_h);   % is 2 or 8? ===>must be some problem here!
Gridy = setdiff(Gridy, [(W-size_h+1):W]);  % delete rest elements
Gridx = 1:size_h - overlap_h : H-(mod(H,size_h-overlap_h)+1+size_h-overlap_h);
Gridx = setdiff(Gridx, [(H-size_h+1):H]);  % delete rest elements

cnt = 0;
cntMat = zeros(size(mIm));

hIm = zeros(H,W);
A = zeros(H, W);
B = zeros(H, W);
hIm1 = zeros(H,W);
hIm2 = zeros(H,W);
hIm3 = zeros(H,W);
for i = 1: length(gridx)
    for j = 1:length(gridy)
        cnt = cnt + 1;
        xx = gridx(i);
        yy = gridy(j);
        XX = Gridx(i);
        YY = Gridy(j);      
        mPatch = mIm(xx:xx+size_low-1, yy:yy+size_low-1);
        %===========iterative patch sr=============%
        %----before---
   %[hPatch, hPatch1, hPatch2, hPatch3] = iterativePatchsr(T, TT, K, KK, P, PP, mPatch, invA, para, scale);
        
       %----after revise---
   [hPatch, hPatch1, hPatch2, hPatch3] = iterativePatchsr_revise(T, TT, K, KK, P, PP, mPatch, Matrix, para, scale);

%-------------------------overlap1-----------------------------------------------
   A(XX:XX+size_h-1, YY:YY+size_h-1) = A(XX:XX+size_h-1, YY:YY+size_h-1) + hPatch;
   B(XX:XX+size_h-1, YY:YY+size_h-1) = B(XX:XX+size_h-1, YY:YY+size_h-1) + 1;

   hIm1(XX:XX+size_h-1, YY:YY+size_h-1) = hIm1(XX:XX+size_h-1, YY:YY+size_h-1) + hPatch1;
   hIm2(XX:XX+size_h-1, YY:YY+size_h-1) = hIm2(XX:XX+size_h-1, YY:YY+size_h-1) + hPatch2;
   hIm3(XX:XX+size_h-1, YY:YY+size_h-1) = hIm3(XX:XX+size_h-1, YY:YY+size_h-1) + hPatch3;        
 
%-------------------------overlap2-----------------------------------------------
%         patch_pre = hIm(XX:XX+size_h-1, YY:YY+size_h-1) ;
%         X = zeros(size_h);
%         X(patch_pre==0) = 1;
%         X(patch_pre~=0) = 1/2;
%         
%         hIm(XX:XX+size_h-1, YY:YY+size_h-1) = hIm(XX:XX+size_h-1, YY:YY+size_h-1)/2 + X.*hPatch;
%         
%         hIm1(XX:XX+size_h-1, YY:YY+size_h-1) = hIm1(XX:XX+size_h-1, YY:YY+size_h-1)/2 + X.*hPatch1;
%         hIm2(XX:XX+size_h-1, YY:YY+size_h-1) = hIm2(XX:XX+size_h-1, YY:YY+size_h-1)/2 + X.*hPatch2;
%         hIm3(XX:XX+size_h-1, YY:YY+size_h-1) = hIm3(XX:XX+size_h-1, YY:YY+size_h-1)/2 + X.*hPatch3;        
     end
end

B(B==0) = 1;
hIm = A./B;
im_h_y = hIm;

im_h_t = hIm1./B;
im_h_k = hIm2./B;
im_h_e = hIm3./B;

% % ----- bicubic to deal with the boundary
Mak = zeros(size(im_h_y));
Mak(im_h_y==0) = 1;
Mak(im_h_y~=0) = 0;
Bi = imresize(im_y, [H W], 'bicubic');
im_h_y = (~Mak).*im_h_y + Mak.*Bi;

% make a post-process just like the way of Yang et al. 2010TIP's work
im_h_y = backprojection(im_h_y, im_y, 20); 
        
 


