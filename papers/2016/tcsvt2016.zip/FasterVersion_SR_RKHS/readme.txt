%%%%%%%%%%%%%%%%%%%%%%%%
Please run ��demo_Psai.m�� 
Type 1: run the method on separated RGB space
Type 2: run the method on Y channel of YUV space

author: Liang-Jian Deng (UESTC, China) at CWRU, Cleveland, OH
time: June 2014

