%% ====(A version that sends to students)===============
% This is a demo to realize the signal recovery
% by ADMM algorithm., i.e., realizeing Algorithm 1 
% in the pdf file. 
% To finish Algorithm 1, please fill in lines 42 -74!
% LJ Deng (UESTC), 2020-03-10
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ===simulating A, x_true, y====
clear; close all; clc;
rng(0);  % for reproducibility, do not change it!
m = 50;  % num samples
n = 200; % num variables, note that n > m

A = rand(m, n);  % simulate matrix A
x_true = zeros(n, 1); % simulate true sparse signal x: line 13-16
nz = 10;         % 
nz_idx = randperm(n);
x(nz_idx(1:nz)) = 2 * rand(nz, 1);
y = A*x_true;         % simulate a degraded signal
y = y + 0.1 * rand(m, 1); % add some noise to the degraded signal

%% ============================
% Problem: min_{x} ||Ax - y||_{1} + lambda ||x||_{1}
%% ======ADMM==================
[m, n] = size(A);
%-initial setting for the ADMM algorithm 
% (neccesary operations for iteartive Algo.)

x = zeros(n,1);  
b1 = zeros(m,1);
b2 = zeros(n,1);

beta1 = 1e-1;  % The para. in Algrithm 1
beta2 = 1e-2;
lambda = 1e-2;

k=0;
ReErr=1;
maxitr = 500;
tol  = 1e-8;

%% ===start the main part of ADMM algorithm
while ReErr> tol && k<maxitr
%% u- sbuproblem (please write down the code 
%  accoridng to Eq.(7))




%% v- sbuproblem (please write down the code 
% accoridng to Eq.(9))




%% x- sbuproblem (please write down the code 
% accoridng to Eq.(11))





%% update b1, b2 (please write down the code 
% accoridng to Eq.(12))




%% update "ReErr" by the step 5 of Algorithm 1





%%
k=k+1;
    
end

%% ====show recovery result =======
figure,
subplot(1, 3, 1);
plot(x_true,'b-','Linewidth',2), axis tight;
title('Original true signal: x_true');

subplot(1, 3, 2);
plot(y,'r-','Linewidth',2), axis tight;
title('Noisy signal: y=Ab');

subplot(1, 3, 3);
plot(x,'g-','Linewidth',2), axis tight;
title('recoverd signal: x by the solution of (1)');






