function [r, w] = func(x)  % main function
% this is a function to compute power value

r = x.^2;

w = power3(x);

end


%%% subfunction

function w = power3(x) % subfucntion

w = x.^3;

end