function func2() % main function
% this is a function to compute power value

x = 3;

r = x.^2;

w = power3(x);

end

%%% subfunction

function w = power3(x) % subfucntion

%w = x.^3;

g = power3(3);

end