% this is a script demo 
% LJ Deng(UESTC), 2020-03-17

clear; close all; clc;

addpath('Exp2')

x = 3;

[a, b] = func(x);

a

b