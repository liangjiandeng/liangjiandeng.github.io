%% K-means demo:
%     recoverData.m
%     computeCentroids.m
%     findClosestCentroids.m
%     kMeansInitCentroids.m
% LJ Deng(UESTC); 2020-04-19
% Thanks for partial code of A. Ng

%% Initialization
clear ; close all; clc

%% =================== K-Means Clustering ======================
%  In this part, you will run the K-Means algorithm on
%  the example dataset we have provided. 

fprintf('\nRunning K-Means clustering on example dataset.\n\n');

% Load an example dataset
load('ex7data2.mat');   % load X: 300x2 which means having 300 2D data

% Settings for running K-Means
K = 3;   % you can change to other number; here 3 clusters
max_iters = 10;

% Initial Centroids
initial_centroids = [3 3; 6 2; 8 5];

% Initialize values
[m n] = size(X);
centroids = initial_centroids;
previous_centroids = centroids;
idx = zeros(m, 1);

% Plot the data if we are plotting progress
plot_progress = 1; % if =1 (plot the clustering progress); otherwise, not plot
if plot_progress
    figure;
    hold on;
end

% Run K-Means
for i=1:max_iters
    
    % Output progress
    fprintf('K-Means iteration %d/%d...\n', i, max_iters);
    if exist('OCTAVE_VERSION')
        fflush(stdout);
    end
    
    % For each example in X, assign it to the closest centroid 
    idx = findClosestCentroids(X, centroids);  % Please finish this function !!!! (Problem A)
    
    % Optionally, plot progress here
    if plot_progress
        plotProgresskMeans(X, centroids, previous_centroids, idx, K, i);
        previous_centroids = centroids;
        fprintf('Press enter to continue.\n');
        pause(1);
    end
    
    % Given the memberships, compute new centroids
    centroids = computeCentroids(X, idx, K);  % Please finish this function !!!! (Problem B)
end




%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% %%%%%%%%%%%%%%%%Subfunctions you need to fill in (for student)%%%%%%%%
%% --subfucntion 1:
function idx = findClosestCentroids(X, centroids)
%FINDCLOSESTCENTROIDS computes the centroid memberships for every example
%   idx = FINDCLOSESTCENTROIDS (X, centroids) returns the closest centroids
%   in idx for a dataset X where each row is a single example. idx = m x 1 
%   vector of centroid assignments (i.e. each entry in range [1..K])
%

    % Set K
    K = size(centroids, 1);

    % You need to return the following variables correctly.
    idx = zeros(size(X,1), 1);  %300x1

% fill in code of (A) in the following (use 'for' loop):



end

%% --subfucntion 2:
function centroids = computeCentroids(X, idx, K)
%COMPUTECENTROIDS returns the new centroids by computing the means of the 
%data points assigned to each centroid.
%   centroids = COMPUTECENTROIDS(X, idx, K) returns the new centroids by 
%   computing the means of the data points assigned to each centroid. It is
%   given a dataset X where each row is a single data point, a vector
%   idx of centroid assignments (i.e. each entry in range [1..K]) for each
%   example, and K, the number of centroids. You should return a matrix
%   centroids, where each row of centroids is the mean of the data points
%   assigned to it.

% Useful variables
[m n] = size(X);

% You need to return the following variables correctly.
centroids = zeros(K, n);

% fill in code of (B) in the following (use 'find' to find idx == i):



end



%% --subfunction 3:
function plotProgresskMeans(X, centroids, previous, idx, K, i)
%PLOTPROGRESSKMEANS is a helper function that displays the progress of 
%k-Means as it is running. It is intended for use only with 2D data.
%   PLOTPROGRESSKMEANS(X, centroids, previous, idx, K, i) plots the data
%   points with colors assigned to each centroid. With the previous
%   centroids, it also plots a line between the previous locations and
%   current locations of the centroids.

    % Plot the examples
    plotDataPoints(X, idx, K);

    % Plot the centroids as black x's
    plot(centroids(:,1), centroids(:,2), 'x', ...
         'MarkerEdgeColor','k', ...
         'MarkerSize', 10, 'LineWidth', 3);

    % Plot the history of the centroids with lines
    for j=1:size(centroids,1)
        drawLine(centroids(j, :), previous(j, :));
    end

    % Title
    title(sprintf('Iteration number %d', i))

end


%%%%%%%%%%%%%%%%%%%END%%%%%%%%%%%%%%%%%%%%%%%%%%


