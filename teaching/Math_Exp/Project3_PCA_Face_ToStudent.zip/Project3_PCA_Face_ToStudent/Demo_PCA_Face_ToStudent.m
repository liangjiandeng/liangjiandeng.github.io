% This is a demo for PCA: compressing face imgs, then recovered face
% from the compressed face imgs.
% Codes from the course of A. Ng
% LJ Deng(UESTC); 2020-04-6

clear; close all;

%% =============== Part 1: Loading and Visualizing Face Data =============
%  We start the exercise by first loading and visualizing the dataset.
%  The following code will load the dataset into your environment
%
fprintf('\nLoading face dataset.\n\n');

%  Load Face dataset
load ('ex7faces.mat')

%  Display the first 100 faces in the dataset
figure,
displayData(X(1:100, :)); title('Display the first 100 faces in the dataset')

fprintf('Program paused. Press enter to continue.\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% =========== Part 2: PCA on Face Data: Eigenfaces  ===================
%  Run PCA and visualize the eigenvectors which are in this case eigenfaces
%  We display the first 36 eigenfaces.
%
fprintf(['\nRunning PCA on face dataset.\n' ...
         '(this might take a minute or two ...)\n\n']);

%  Before running PCA, it is important to first normalize X by subtracting 
%  the mean value from each feature, i.e.,

%  Step 1): Please finish the following code of featureNormalize:
  [X_norm, mu, sigma] = featureNormalize(X);  


%  Step 2) + Step 3): Pleas finish the code of [U, S] = pca(X_norm);
%  [U, S] = pca(X_norm);  

%  Visualize the top 36 eigenvectors (eigen-faces) found
figure,
displayData(U(:, 1:36)'); title('Visualize the top 36 eigenvectors found')
fprintf('Program paused. Press enter to continue.\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ============= Part 3: Dimension Reduction for Faces =================
%  Project images to the eigen space using the top k eigenvectors 
%  If you are applying a machine learning algorithm 
fprintf('\nDimension reduction for face dataset.\n\n');

K = 100;
%  Step 4 + Step 5): Pleas finish the code of projectData(X_norm, U, K);
%  Z = projectData(X_norm, U, K);

fprintf('The projected data Z has a size of: ')
fprintf('%d ', size(Z));

fprintf('\n\nProgram paused. Press enter to continue.\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ==== Part 4: Visualization of Faces after PCA Dimension Reduction ====
%  Project images to the eigen space using the top K eigen vectors and 
%  visualize only using those K dimensions
%  Compare to the original input, which is also displayed

fprintf('\nVisualizing the projected (reduced dimension) faces.\n\n');

K = 100;
%  Step 6): Pleas finish the code of recoverData(Z, U, K);
%  X_rec  = recoverData(Z, U, K);

%% ============ Part 5: Display normalized data ================
figure,
subplot(1, 3, 1);
displayData(X_norm(1:100,:));
title('Original faces');
axis square;

subplot(1, 3, 2);
displayData(Z(1:100,:));
title('Compressed faces');
axis square;

% Display reconstructed data from only k eigenfaces
subplot(1, 3, 3);
displayData(X_rec(1:100,:));
title('Recovered faces');
axis square;

fprintf('Program paused. Press enter to continue.\n');