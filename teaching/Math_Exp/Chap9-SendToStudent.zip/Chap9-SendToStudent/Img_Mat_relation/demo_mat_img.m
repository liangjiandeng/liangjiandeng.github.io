% This is a demo to illustrate the relationshop between the matrix and the
% image
% LJ Deng (UESTC); 2020-04-06

clear; close all
I = imread('color_img.png');
I = double(I)/255;
figure, 
subplot(2,2,1), imshow(I); title('show color fig.')
subplot(2,2,2), imshow(I(:,:,1)); title('show color fig.')
subplot(2,2,3), imshow(I(:,:,2)); title('show color fig.')
subplot(2,2,4), imshow(I(:,:,3)); title('show color fig.')

G = rgb2gray(I); 
W = G;
figure,imshow(G); title('Gray Img.')

G(50:100, :) = 0;  % 让图像某行为0（黑色）
figure,imshow(G); title('Img.1')
G(:, 50:100) = 1;  % 让图像某列为0（黑色）
figure,imshow(G); title('Img.2')
G(50:100, :) = [];  % 删除图像某行
figure,imshow(G); title('Img.3')
G(:, 50:100) = [];  % 删除图像某列
figure,imshow(G); title('Img.4')

W = W + rand(size(W));
figure,imshow(W); title('Img.5')
