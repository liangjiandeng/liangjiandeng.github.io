% This is a demo to plot some figures
% @LJ Deng (UESTC), 2020-03-17

clear; close all; clc;

%% ========example 1=======
disp('Exp 1 (plot): y = e^(-0.5x)sin 5x ')

x=0:0.1:4*pi; 
y= exp(-0.5*x);   % e^(-0.5x)
y1=y .*sin(5*x);  % y1 = e^(-0.5x)sin 5x
figure,
plot(x, y1, x,y,'--r', x,-y,'--b')
title('Exp 1 (plot): y = e^{(-0.5x)}sin 5x')
xlabel('x');
ylabel('y');
legend('exp(-0.5x)sin(5x)','exp(-0.5x)', '-exp(-0.5x)')

%% ========example 2=======
disp('Exp 2 (plot): y = sin(x), z = cos(x)')

x=linspace(0, 2*pi, 30);
y=sin(x);
z=cos(x);
figure,
plot(x, y, x, z, 'LineWidth', 1.5)
legend('sin(x)','cos(x)')
title('Exp 2 (plot): y = sin(x), z = cos(x)')

%% ========example 3=======
disp('Exp 3 (ezplot): y = e^(-0.5x)sin 5x ')

figure,
ezplot('exp(-0.5*x)*sin(5*x)',[0,10,-1,1])
title('Exp 3 (ezplot): y = e^{(-0.5x)}sin 5x ')
legend('exp(-0.5x)sin(5x)')


%% ========example 4=======
disp('Exp 4 (polar): r =1+2�� ')

theta=0:pi/20:4*pi;
rho= 1 + theta*2;
figure,
polar(theta,rho,'r')
title('Exp 4 (polar): r =1+2��')

%% ========example 5=======
disp('Exp 5 (polar): rho = a cos(3theta)')

a = 1;
theta=0:0.001:2*pi;
r=a*cos(3*theta);
figure,
polar(theta,r,'k') 
title('Exp 5 (polar): rho = a cos(3theta)')

%% ========example 6=======
disp('Exp 6 (bar, bar3): y= exp(-x.*x)')

x=-2.9:0.2:2.9;
y= exp(-x.*x);
figure,
subplot(1,2,1)
bar(x,y)
title('(2D bar): y= exp(-x.*x)')
subplot(1,2,2)
bar3(x,y)
title('(3D bar): y= exp(-x.*x)') 

%% ========example 7=======
disp('Exp 7 (plot3): x=sin(t),y=cos(t),z=t')

t=linspace(0,10*pi);

figure,
plot3(sin(t),cos(t),t)
xlabel('sin(t)')
ylabel('cos(t)')
zlabel('t')
%grid on
title('Figure: helix')

%% ========example 8=======
disp('Exp 8 (mesh): z = x exp(�Cx^2 �C y^2)')

[x,y]=meshgrid(-2:0.2:2);  % firs step (must do!)
z=x.*exp(-x.^2-y.^2);      % point-to-point operation!
figure,
mesh(x,y,z)
grid on
colormap([0 0 1])          % blue color surface

%% ========example 9=======
disp('Exp 9 (meshc, meshz): z = x exp(�Cx^2 �C y^2)')

[x,y]=meshgrid(-2:0.2:2);
z=x.*exp(-x.^2-y.^2);  
figure,
subplot(1,2,1), meshc(x,y,z)
title('Figure 1:mesh plot with Contours')
subplot(1,2,2),meshz(x,y,z)
title('Figure 2:mesh plot with Zero Plan')

%% ========example 10=======
disp('Exp 10 (contour, contour3): z = x exp(�Cx^2 �C y^2)')

[x,y]=meshgrid(-2:0.2:2);
z=x.*exp(-x.^2-y.^2);  
figure,
subplot(1,2,1), contour(x,y,z,20)
title('Figure 1: 2-D Contour Plot')
subplot(1,2,2), contour3(x,y,z,20)
title('Figure 2: 3-D Contour Plot')


%% ========example 11=======
disp('Exp 11 (imread, imshow, reshape): exampel for image processing')

%% ---show clean img:
I = double(imread('figs/lena.pgm'))/255;  % satellite256
% or use: I = imread('figs/lena.pgm');

figure,   % show clear img.
imshow(I); title('show clean Image')

%% ---add noise to clean img:
% %--case 1: add Gaussian noise(non-sparse)
% noise = randn(size(I));  % or use command: imnoise
% noise_level = 0.1;
% I_noise = I + noise_level*noise;
% figure,   % show noisy img.
% imshow(I_noise); title('show noisy Image')

%--case 2: add sparse noise ('salt & pepper')
d   = 0.05; % increase d to increase noise density
I_noise = imnoise(I,'salt & pepper',d);
noise   = I_noise - I;  % noise 
figure,   % show noisy img.
imshow(I_noise); title('show noisy Image')

%% ---reshape Image (2D matrix) to Signal (1D vector)
I_vector = reshape(I, [size(I,1)*size(I,2), 1]); %or use: I_vector = I(:);
figure,   % show clean vector
imshow(I_vector); title('show clean vector')

%% ---reshape Signal (1D vector) to Image (2D matrix)
I_reshape = reshape(I_vector, [size(I,1), size(I,2)]); 
figure,   % show clean vector
imshow(I_reshape); title('show reshaped Img. for the vector')

%% ---subplot to show all Imgs.
figure,
subplot(2,2,1),imshow(I,[]); title('clean Img.')
subplot(2,2,2),imshow(noise_level*noise, []); title('noise')
subplot(2,2,3),imshow(I_noise, []); title('noisy Img.')
subplot(2,2,4),imshow(I_reshape, []); title('reshaped Img.')

%% =========================END=============================









