% This is a demo for the training in the teaching of Chap5
% LJ Deng(UESTC); 2020-03-22

clear; close all;

fprintf('Input the index of the problem you chosen')
Index_Pro = input('Index_Pro Could be: 1, 2 , 3:  ');


switch  Index_Pro
    case 1
        [X, Y] = meshgrid(-8:0.1:8);
        Z      = sqrt(3*X.^2 + 2*Y.^2);
        figure,
        subplot(2,2,1), mesh(X,Y,Z); title('mesh plot');
        subplot(2,2,2), meshc(X,Y,Z); title('mesh plot with Contours');
        subplot(2,2,3), meshz(X,Y,Z); title('mesh plot with Zero Plane');
    
    case 2
        [X, Y] = meshgrid(-100:0.1:100);
        fprintf('This is a demo to plot mesh with different p and q...')
        
        figure,
        for p = -3:3
            for q = -3:3
                Z = plotmesh(X, Y, p, q);  % call subfunction plotmesh.m
            end
        end
        
    case 3
        [x,y]=meshgrid(-8:0.5:8); % get grids
        r=sqrt(x.^2+y.^2)+eps;    % must add eps to avoid sigularity
        z=sin(r)./r;
        figure,
        mesh(x,y,z)
        colormap([1,0,0])
    
end

%% =================================================%%
%%%%%%%%%%%%%%%%%subfunction%%%%%%%%%%%%%%%%%%%%%%%%%%
function Z = plotmesh(X, Y, p, q)

Z = X.^2/(2*p) + Y.^2/(2*q);

mesh(X, Y, Z);
%colormap([0 0 1])
title(['Plot mesh: z = x^2/2p + y^2/2q, when p = ', num2str(p), ' ', '; q = ', num2str(q)]);
pause(1)
end


