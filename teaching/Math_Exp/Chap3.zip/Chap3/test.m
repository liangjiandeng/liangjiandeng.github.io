% This is a demo for chap 3
% LJ Deng (UESTC), 2020-03-17

clear; close all; clc;

M =[]; y =1;
while y<=1000
   x = sqrt(1+2*y);
   if fix(x)==x
        M = [ M; x y];
   end
   y= y+1;
end
disp(sprintf('NO. =%d',size(M,1)));
disp('Results #:')
disp(M)
