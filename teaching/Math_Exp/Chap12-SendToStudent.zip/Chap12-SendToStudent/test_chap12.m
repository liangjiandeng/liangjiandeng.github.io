% This is a demo to test the ODE numerical solution  
clear; close all;


% %% =====exm1=======
% [t,N]=ode23(@fun1,[1994:2020],12);
% plot(t,N,'o')
% 
% 
% function dfun=fun1(t, N)
% dfun=0.015*N; 
% end


% %% =====exm2=======
% y0=[0;2];
% tn=[0,3];
% [t,y]=ode23(@fun2,tn,y0);
% plot(t,y(:,1),'o',t,y(:,2),'+')
% xlabel('t');ylabel('y_1 and y_2');
% legend('y_1','y_2')
% 
% 
% function dfun=fun2(t,y)
% dfun=[-y(1)*exp(1-t)+0.8*y(2);
%              y(1)-y(2)^3];
% end


% % %% =====exm3=======
% h = 0.1; tn = 1;
% t=(0:h:tn)';
% n=length(t);
% y=1*ones(n,1);
% for k=2:n
%   y(k)=y(k-1)+h*feval(t(k-1),y(k-1));
% end
% plot(t, y, 'sb-')
% 
% function dfun=feval(t, y)
% dfun=t - 2*y; 
% end


% % %% =====exm4=======
% Y0=[100; 20];
% [t,Y]=ode23(@fox,[0,20],Y0);
% x=Y(:,1);y=Y(:,2);
% figure(1),plot(t,x,'b',t,y,'r')
% figure(2),plot(x,y) 
% 
% function z=fox(t,y)
% z(1,:)=y(1)-0.015*y(1).*y(2);
% z(2,:)=-y(2)+0.01*y(1).*y(2);
% end


% % %% =====exm5=======
% x0=[1;0];
% tn=[0,20];
% [t,y]=ode45(@vdpol,tn,x0);
% plot(t,y(:,1),t,y(:,2),'--')
% xlabel('t');ylabel('y_1 and y_2');
% legend('y_1','y_2')
% 
% function dfun=vdpol(t,x)
%  u=2;
%  dfun=[x(2);u*(1-x(1)^2)*x(2)-x(1)];
% end


